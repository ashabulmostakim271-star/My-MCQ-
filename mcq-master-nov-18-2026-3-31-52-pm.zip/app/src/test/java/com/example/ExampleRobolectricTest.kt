package com.example

import android.content.Context
import androidx.room.Room
import androidx.test.core.app.ApplicationProvider
import com.example.data.local.AppDatabase
import com.example.data.local.ChapterEntity
import com.example.data.local.McqEntity
import com.example.data.local.QuizSessionEntity
import com.example.data.local.SubjectEntity
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.test.runTest
import org.junit.After
import org.junit.Assert.assertEquals
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class ExampleRobolectricTest {

    private lateinit var db: AppDatabase

    @Before
    fun setup() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        db = Room.inMemoryDatabaseBuilder(context, AppDatabase::class.java)
            .allowMainThreadQueries()
            .build()
    }

    @After
    fun tearDown() {
        db.close()
    }

    @Test
    fun `app name matches MCQ Master`() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val appName = context.getString(R.string.app_name)
        assertEquals("MCQ Master", appName)
    }

    @Test
    fun `room stores and selectively deletes input and output history`() = runTest {
        val dao = db.mcqDao()
        val subjectId = dao.insertSubject(SubjectEntity(name = "পদার্থবিজ্ঞান", iconEmoji = "⚛️"))
        val chapterId1 = dao.insertChapter(ChapterEntity(subjectId = subjectId, name = "অধ্যায় ৩: বল"))
        val chapterId2 = dao.insertChapter(ChapterEntity(subjectId = subjectId, name = "অধ্যায় ৪: কাজ"))

        dao.insertMcqs(
            listOf(
                McqEntity(
                    chapterId = chapterId1,
                    question = "বলের একক কী?",
                    optionA = "জুল",
                    optionB = "নিউটন",
                    optionC = "ওয়াট",
                    optionD = "প্যাসকেল",
                    correctAnswer = "B",
                    explanation = "F = ma অনুসারে বলের SI একক নিউটন (N)।"
                ),
                McqEntity(
                    chapterId = chapterId2,
                    question = "কাজের একক কী?",
                    optionA = "জুল",
                    optionB = "নিউটন",
                    optionC = "ওয়াট",
                    optionD = "প্যাসকেল",
                    correctAnswer = "A",
                    explanation = null
                )
            )
        )

        val inputHistory = dao.observeInputHistory().first()
        assertEquals(2, inputHistory.size)

        val sessionId1 = dao.insertQuizSession(
            QuizSessionEntity(
                subjectId = subjectId,
                chapterId = chapterId1,
                score = 1,
                total = 1,
                wrongCount = 0,
                skippedCount = 0,
                durationSeconds = 12
            )
        )
        val sessionId2 = dao.insertQuizSession(
            QuizSessionEntity(
                subjectId = subjectId,
                chapterId = chapterId2,
                score = 0,
                total = 1,
                wrongCount = 1,
                skippedCount = 0,
                durationSeconds = 10
            )
        )

        assertEquals(2, dao.observeQuizSessions().first().size)

        // Selective delete 1 output session
        dao.deleteSessionsByIds(listOf(sessionId1))
        val remainingSessions = dao.observeQuizSessions().first()
        assertEquals(1, remainingSessions.size)
        assertEquals(sessionId2, remainingSessions[0].id)

        // Selective delete 1 input chapter (cascades its MCQs)
        dao.deleteChaptersByIds(listOf(chapterId1))
        val remainingInputs = dao.observeInputHistory().first()
        assertEquals(1, remainingInputs.size)
        assertEquals(chapterId2, remainingInputs[0].chapterId)
        assertEquals(1, dao.observeTotalMcqCount().first())
    }
}
