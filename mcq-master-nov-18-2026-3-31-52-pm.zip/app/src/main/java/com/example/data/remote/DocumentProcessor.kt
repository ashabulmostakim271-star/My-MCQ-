package com.example.data.remote

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.pdf.PdfRenderer
import android.net.Uri
import android.provider.OpenableColumns
import android.util.Base64
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.ByteArrayOutputStream
import kotlin.math.max
import kotlin.math.roundToInt

enum class SourceFileType {
    PDF,
    IMAGE
}

data class PickedDocumentInfo(
    val uri: Uri,
    val displayName: String,
    val type: SourceFileType,
    val pageCount: Int
)

data class EncodedPageImage(
    val mimeType: String,
    val base64Data: String
)

class DocumentProcessor(private val context: Context) {

    suspend fun inspectUri(uri: Uri, type: SourceFileType): PickedDocumentInfo =
        withContext(Dispatchers.IO) {
            val name = resolveDisplayName(uri) ?: if (type == SourceFileType.PDF) {
                "document.pdf"
            } else {
                "image.jpg"
            }
            val pages = if (type == SourceFileType.PDF) {
                countPdfPages(uri)
            } else {
                1
            }
            PickedDocumentInfo(
                uri = uri,
                displayName = name,
                type = type,
                pageCount = pages
            )
        }

    suspend fun renderToBase64Images(
        doc: PickedDocumentInfo,
        maxPages: Int = MAX_PDF_PAGES
    ): Result<List<EncodedPageImage>> = withContext(Dispatchers.IO) {
        runCatching {
            when (doc.type) {
                SourceFileType.IMAGE -> listOf(encodeImageUri(doc.uri))
                SourceFileType.PDF -> renderPdfPages(doc.uri, maxPages)
            }
        }
    }

    private fun resolveDisplayName(uri: Uri): String? {
        return runCatching {
            context.contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)
                ?.use { cursor ->
                    if (cursor.moveToFirst()) {
                        val idx = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                        if (idx >= 0) cursor.getString(idx) else null
                    } else null
                }
        }.getOrNull()
    }

    private fun countPdfPages(uri: Uri): Int {
        return runCatching {
            context.contentResolver.openFileDescriptor(uri, "r")?.use { pfd ->
                PdfRenderer(pfd).use { renderer ->
                    renderer.pageCount
                }
            } ?: 0
        }.getOrDefault(0)
    }

    private fun encodeImageUri(uri: Uri): EncodedPageImage {
        val rawBytes = context.contentResolver.openInputStream(uri)?.use { it.readBytes() }
            ?: throw IllegalStateException("Could not open selected image.")

        val options = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        BitmapFactory.decodeByteArray(rawBytes, 0, rawBytes.size, options)

        val maxDim = max(options.outWidth, options.outHeight)
        val sampleSize = if (maxDim > MAX_IMAGE_DIMENSION) {
            var s = 1
            while (maxDim / (s * 2) >= MAX_IMAGE_DIMENSION) {
                s *= 2
            }
            s
        } else 1

        val decodeOptions = BitmapFactory.Options().apply {
            inSampleSize = sampleSize
            inPreferredConfig = Bitmap.Config.ARGB_8888
        }
        val decoded = BitmapFactory.decodeByteArray(rawBytes, 0, rawBytes.size, decodeOptions)
            ?: throw IllegalStateException("Unable to decode image file.")

        val scaled = scaleBitmapIfNeeded(decoded, MAX_IMAGE_DIMENSION)
        if (scaled !== decoded) decoded.recycle()

        val encoded = bitmapToBase64Jpeg(scaled, JPEG_QUALITY)
        scaled.recycle()
        return EncodedPageImage(mimeType = "image/jpeg", base64Data = encoded)
    }

    private fun renderPdfPages(uri: Uri, maxPages: Int): List<EncodedPageImage> {
        val result = mutableListOf<EncodedPageImage>()
        val pfd = context.contentResolver.openFileDescriptor(uri, "r")
            ?: throw IllegalStateException("Could not open selected PDF file.")

        pfd.use { descriptor ->
            PdfRenderer(descriptor).use { renderer ->
                if (renderer.pageCount == 0) {
                    throw IllegalStateException("Selected PDF has no pages.")
                }
                val pagesToRender = minOf(renderer.pageCount, maxPages)
                for (index in 0 until pagesToRender) {
                    renderer.openPage(index).use { page ->
                        val scale = (TARGET_PDF_WIDTH.toFloat() / max(page.width, 1))
                            .coerceIn(1.0f, 3.0f)
                        val width = (page.width * scale).roundToInt().coerceAtMost(MAX_IMAGE_DIMENSION)
                        val height = (page.height * scale).roundToInt().coerceAtMost(MAX_IMAGE_DIMENSION)

                        val bitmap = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
                        val canvas = Canvas(bitmap)
                        canvas.drawColor(Color.WHITE)
                        page.render(bitmap, null, null, PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY)

                        val base64 = bitmapToBase64Jpeg(bitmap, JPEG_QUALITY)
                        bitmap.recycle()
                        result.add(EncodedPageImage(mimeType = "image/jpeg", base64Data = base64))
                    }
                }
            }
        }
        return result
    }

    private fun scaleBitmapIfNeeded(bitmap: Bitmap, maxDim: Int): Bitmap {
        val currentMax = max(bitmap.width, bitmap.height)
        if (currentMax <= maxDim) return bitmap
        val ratio = maxDim.toFloat() / currentMax.toFloat()
        val newW = (bitmap.width * ratio).roundToInt().coerceAtLeast(1)
        val newH = (bitmap.height * ratio).roundToInt().coerceAtLeast(1)
        return Bitmap.createScaledBitmap(bitmap, newW, newH, true)
    }

    private fun bitmapToBase64Jpeg(bitmap: Bitmap, quality: Int): String {
        val out = ByteArrayOutputStream()
        bitmap.compress(Bitmap.CompressFormat.JPEG, quality, out)
        return Base64.encodeToString(out.toByteArray(), Base64.NO_WRAP)
    }

    companion object {
        private const val MAX_IMAGE_DIMENSION = 1600
        private const val TARGET_PDF_WIDTH = 1400
        private const val JPEG_QUALITY = 85
        const val MAX_PDF_PAGES = 15
    }
}
