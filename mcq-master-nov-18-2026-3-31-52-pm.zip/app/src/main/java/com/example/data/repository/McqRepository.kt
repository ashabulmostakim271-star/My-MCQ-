package com.example.data.repository

import android.net.Uri
import com.example.data.local.ApiKeyStatus
import com.example.data.local.AppLanguage
import com.example.data.local.AppPreferences
import com.example.data.local.ChapterEntity
import com.example.data.local.ChapterWithCount
import com.example.data.local.ExplanationMode
import com.example.data.local.InputHistoryItem
import com.example.data.local.McqDao
import com.example.data.local.McqEntity
import com.example.data.local.PreferencesManager
import com.example.data.local.QuizSessionEntity
import com.example.data.local.QuizSessionWithMeta
import com.example.data.local.SecureKeyManager
import com.example.data.local.SubjectEntity
import com.example.data.local.SubjectWithStats
import com.example.data.remote.DocumentProcessor
import com.example.data.remote.ExtractedMcqDraft
import com.example.data.remote.GeminiApiClient
import com.example.data.remote.PickedDocumentInfo
import com.example.data.remote.SourceFileType
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.flowOn
import kotlinx.coroutines.withContext
import java.util.Calendar

class McqRepository(
    private val dao: McqDao,
    private val secureKeyManager: SecureKeyManager,
    private val preferencesManager: PreferencesManager,
    private val documentProcessor: DocumentProcessor,
    private val geminiApiClient: GeminiApiClient
) {
    val subjectsWithStats: Flow<List<SubjectWithStats>> =
        dao.observeSubjectsWithStats().flowOn(Dispatchers.IO)

    val allChapters: Flow<List<ChapterWithCount>> =
        dao.observeAllChapters().flowOn(Dispatchers.IO)

    val inputHistory: Flow<List<InputHistoryItem>> =
        dao.observeInputHistory().flowOn(Dispatchers.IO)

    val totalMcqCount: Flow<Int> =
        dao.observeTotalMcqCount().flowOn(Dispatchers.IO)

    val quizSessions: Flow<List<QuizSessionWithMeta>> =
        dao.observeQuizSessions().flowOn(Dispatchers.IO)

    val preferencesFlow: Flow<AppPreferences> =
        preferencesManager.preferencesFlow.flowOn(Dispatchers.IO)

    val apiKeyState: StateFlow<String> = secureKeyManager.apiKeyState
    val apiConnectionStatus: StateFlow<ApiKeyStatus> = secureKeyManager.connectionStatus

    fun observeTodaySessionsCount(): Flow<Int> {
        val cal = Calendar.getInstance().apply {
            set(Calendar.HOUR_OF_DAY, 0)
            set(Calendar.MINUTE, 0)
            set(Calendar.SECOND, 0)
            set(Calendar.MILLISECOND, 0)
        }
        return dao.observeTodaySessionsCount(cal.timeInMillis).flowOn(Dispatchers.IO)
    }

    suspend fun addSubject(name: String, emoji: String): Long = withContext(Dispatchers.IO) {
        dao.insertSubject(SubjectEntity(name = name.trim(), iconEmoji = emoji))
    }

    suspend fun updateSubject(subject: SubjectEntity) = withContext(Dispatchers.IO) {
        dao.updateSubject(subject)
    }

    suspend fun deleteSubject(subjectId: Long) = withContext(Dispatchers.IO) {
        dao.deleteSubjectById(subjectId)
    }

    suspend fun deleteChapter(chapterId: Long) = withContext(Dispatchers.IO) {
        dao.deleteChapterById(chapterId)
    }

    suspend fun deleteInputHistoryChapters(chapterIds: List<Long>): Int = withContext(Dispatchers.IO) {
        if (chapterIds.isEmpty()) return@withContext 0
        dao.deleteChaptersByIds(chapterIds)
        chapterIds.size
    }

    suspend fun deleteOutputHistorySessions(sessionIds: List<Long>): Int = withContext(Dispatchers.IO) {
        if (sessionIds.isEmpty()) return@withContext 0
        dao.deleteSessionsByIds(sessionIds)
        sessionIds.size
    }

    suspend fun saveExtractedMcqs(
        subjectId: Long,
        chapterName: String,
        drafts: List<ExtractedMcqDraft>
    ): Int = withContext(Dispatchers.IO) {
        val cleanName = chapterName.trim()
        val existingChapter = dao.findChapterByName(subjectId, cleanName)
        val chapterId = existingChapter?.id ?: dao.insertChapter(
            ChapterEntity(subjectId = subjectId, name = cleanName)
        )
        val entities = drafts.map { draft ->
            McqEntity(
                chapterId = chapterId,
                question = draft.question.trim(),
                optionA = draft.optionA.trim(),
                optionB = draft.optionB.trim(),
                optionC = draft.optionC.trim(),
                optionD = draft.optionD.trim(),
                correctAnswer = draft.correctAnswer,
                explanation = draft.explanation?.trim()?.takeIf { it.isNotEmpty() }
            )
        }
        dao.insertMcqs(entities)
        entities.size
    }

    suspend fun getMcqsForQuiz(subjectId: Long, chapterId: Long?): List<McqEntity> =
        withContext(Dispatchers.IO) {
            if (chapterId != null) {
                dao.getMcqsForChapter(chapterId)
            } else {
                dao.getMcqsForSubject(subjectId)
            }
        }

    suspend fun saveQuizSession(
        subjectId: Long,
        chapterId: Long?,
        score: Int,
        total: Int,
        wrongCount: Int,
        skippedCount: Int,
        durationSeconds: Int
    ): Long = withContext(Dispatchers.IO) {
        dao.insertQuizSession(
            QuizSessionEntity(
                subjectId = subjectId,
                chapterId = chapterId,
                score = score,
                total = total,
                wrongCount = wrongCount,
                skippedCount = skippedCount,
                durationSeconds = durationSeconds
            )
        )
    }

    suspend fun saveApiKey(key: String) = withContext(Dispatchers.IO) {
        secureKeyManager.saveApiKey(key, markVerified = false)
    }

    suspend fun testApiConnection(key: String): Result<Unit> = withContext(Dispatchers.IO) {
        val trimmed = key.trim()
        secureKeyManager.saveApiKey(trimmed, markVerified = false)
        val result = geminiApiClient.testConnection(trimmed)
        if (result.isSuccess) {
            secureKeyManager.setVerified(true)
        } else {
            secureKeyManager.setVerified(false)
        }
        result
    }

    suspend fun setSoundEffects(enabled: Boolean) = withContext(Dispatchers.IO) {
        preferencesManager.setSoundEffects(enabled)
    }

    suspend fun setExplanationMode(mode: ExplanationMode) = withContext(Dispatchers.IO) {
        preferencesManager.setExplanationMode(mode)
    }

    suspend fun setLanguage(language: AppLanguage) = withContext(Dispatchers.IO) {
        preferencesManager.setLanguage(language)
    }

    suspend fun inspectPickedFile(uri: Uri, type: SourceFileType): PickedDocumentInfo =
        documentProcessor.inspectUri(uri, type)

    suspend fun extractMcqsFromDocument(
        doc: PickedDocumentInfo,
        onProgress: (String) -> Unit
    ): Result<List<ExtractedMcqDraft>> = withContext(Dispatchers.IO) {
        val apiKey = secureKeyManager.getApiKey()
        if (apiKey.isEmpty()) {
            return@withContext Result.failure(
                IllegalStateException("Gemini API key is not set. Add your free key in Settings first.")
            )
        }

        val rendered = documentProcessor.renderToBase64Images(doc)
        val pages = rendered.getOrElse { return@withContext Result.failure(it) }

        val result = geminiApiClient.extractMcqs(apiKey, pages) { current, total ->
            if (total > 1) {
                onProgress("Batch $current of $total")
            }
        }
        if (result.isSuccess) {
            secureKeyManager.setVerified(true)
        }
        result
    }
}
