package com.example.data.local

import android.content.Context
import android.content.SharedPreferences
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

enum class ApiKeyStatus {
    NOT_SET,
    SAVED_UNVERIFIED,
    CONNECTED
}

class SecureKeyManager(context: Context) {

    private val prefs: SharedPreferences = createEncryptedPrefs(context)

    private val _apiKeyState = MutableStateFlow(loadStoredKey())
    val apiKeyState: StateFlow<String> = _apiKeyState.asStateFlow()

    private val _connectionStatus = MutableStateFlow(loadInitialStatus())
    val connectionStatus: StateFlow<ApiKeyStatus> = _connectionStatus.asStateFlow()

    private fun createEncryptedPrefs(context: Context): SharedPreferences {
        return try {
            val masterKey = MasterKey.Builder(context.applicationContext)
                .setKeyScheme(MasterKey.KeyScheme.AES256_GCM)
                .build()
            EncryptedSharedPreferences.create(
                context.applicationContext,
                PREFS_NAME,
                masterKey,
                EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
                EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM
            )
        } catch (_: Exception) {
            // If keystore entry is invalidated after backup restore, recreate encrypted prefs cleanly
            context.applicationContext.deleteSharedPreferences(PREFS_NAME)
            val masterKey = MasterKey.Builder(context.applicationContext)
                .setKeyScheme(MasterKey.KeyScheme.AES256_GCM)
                .build()
            EncryptedSharedPreferences.create(
                context.applicationContext,
                PREFS_NAME,
                masterKey,
                EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
                EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM
            )
        }
    }

    private fun loadStoredKey(): String = prefs.getString(KEY_GEMINI_API, "")?.trim().orEmpty()

    private fun loadInitialStatus(): ApiKeyStatus {
        val key = loadStoredKey()
        if (key.isEmpty()) return ApiKeyStatus.NOT_SET
        val verified = prefs.getBoolean(KEY_VERIFIED, false)
        return if (verified) ApiKeyStatus.CONNECTED else ApiKeyStatus.SAVED_UNVERIFIED
    }

    fun getApiKey(): String = _apiKeyState.value

    fun saveApiKey(rawKey: String, markVerified: Boolean = false) {
        val trimmed = rawKey.trim()
        prefs.edit()
            .putString(KEY_GEMINI_API, trimmed)
            .putBoolean(KEY_VERIFIED, markVerified && trimmed.isNotEmpty())
            .apply()
        _apiKeyState.value = trimmed
        _connectionStatus.value = when {
            trimmed.isEmpty() -> ApiKeyStatus.NOT_SET
            markVerified -> ApiKeyStatus.CONNECTED
            else -> ApiKeyStatus.SAVED_UNVERIFIED
        }
    }

    fun setVerified(verified: Boolean) {
        val key = _apiKeyState.value
        prefs.edit().putBoolean(KEY_VERIFIED, verified && key.isNotEmpty()).apply()
        _connectionStatus.value = when {
            key.isEmpty() -> ApiKeyStatus.NOT_SET
            verified -> ApiKeyStatus.CONNECTED
            else -> ApiKeyStatus.SAVED_UNVERIFIED
        }
    }

    fun clearKey() {
        prefs.edit().remove(KEY_GEMINI_API).remove(KEY_VERIFIED).apply()
        _apiKeyState.value = ""
        _connectionStatus.value = ApiKeyStatus.NOT_SET
    }

    companion object {
        private const val PREFS_NAME = "mcq_master_secure_prefs"
        private const val KEY_GEMINI_API = "gemini_api_key"
        private const val KEY_VERIFIED = "gemini_api_verified"
    }
}
