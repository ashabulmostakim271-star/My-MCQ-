package com.example.data.local

import androidx.compose.runtime.Immutable
import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.Index
import androidx.room.PrimaryKey

@Immutable
@Entity(tableName = "subjects")
data class SubjectEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String,
    val iconEmoji: String
)

@Immutable
@Entity(
    tableName = "chapters",
    foreignKeys = [
        ForeignKey(
            entity = SubjectEntity::class,
            parentColumns = ["id"],
            childColumns = ["subjectId"],
            onDelete = ForeignKey.CASCADE
        )
    ],
    indices = [Index("subjectId")]
)
data class ChapterEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val subjectId: Long,
    val name: String,
    val createdAt: Long = System.currentTimeMillis()
)

@Immutable
@Entity(
    tableName = "mcqs",
    foreignKeys = [
        ForeignKey(
            entity = ChapterEntity::class,
            parentColumns = ["id"],
            childColumns = ["chapterId"],
            onDelete = ForeignKey.CASCADE
        )
    ],
    indices = [Index("chapterId")]
)
data class McqEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val chapterId: Long,
    val question: String,
    val optionA: String,
    val optionB: String,
    val optionC: String,
    val optionD: String,
    val correctAnswer: String, // "A", "B", "C", "D", or "UNKNOWN"
    val explanation: String? = null,
    val createdAt: Long = System.currentTimeMillis()
)

@Immutable
@Entity(
    tableName = "quiz_sessions",
    foreignKeys = [
        ForeignKey(
            entity = SubjectEntity::class,
            parentColumns = ["id"],
            childColumns = ["subjectId"],
            onDelete = ForeignKey.CASCADE
        ),
        ForeignKey(
            entity = ChapterEntity::class,
            parentColumns = ["id"],
            childColumns = ["chapterId"],
            onDelete = ForeignKey.SET_NULL
        )
    ],
    indices = [Index("subjectId"), Index("chapterId")]
)
data class QuizSessionEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val subjectId: Long,
    val chapterId: Long?,
    val score: Int,
    val total: Int,
    val wrongCount: Int = 0,
    val skippedCount: Int = 0,
    val dateTaken: Long = System.currentTimeMillis(),
    val durationSeconds: Int
)

@Immutable
data class SubjectWithStats(
    val id: Long,
    val name: String,
    val iconEmoji: String,
    val chapterCount: Int,
    val mcqCount: Int
)

@Immutable
data class ChapterWithCount(
    val id: Long,
    val subjectId: Long,
    val name: String,
    val createdAt: Long,
    val mcqCount: Int,
    val validMcqCount: Int
)

@Immutable
data class InputHistoryItem(
    val chapterId: Long,
    val subjectId: Long,
    val subjectName: String,
    val subjectEmoji: String,
    val chapterName: String,
    val mcqCount: Int,
    val createdAt: Long
)

@Immutable
data class QuizSessionWithMeta(
    val id: Long,
    val subjectId: Long,
    val chapterId: Long?,
    val score: Int,
    val total: Int,
    val wrongCount: Int,
    val skippedCount: Int,
    val dateTaken: Long,
    val durationSeconds: Int,
    val subjectName: String,
    val subjectEmoji: String,
    val chapterName: String?
)
