package com.example.data.local

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import kotlinx.coroutines.flow.Flow

@Dao
interface McqDao {

    // Subjects
    @Query(
        """
        SELECT s.id, s.name, s.iconEmoji,
               (SELECT COUNT(*) FROM chapters c WHERE c.subjectId = s.id) AS chapterCount,
               (SELECT COUNT(*) FROM mcqs m INNER JOIN chapters c ON m.chapterId = c.id WHERE c.subjectId = s.id) AS mcqCount
        FROM subjects s
        ORDER BY s.id ASC
        """
    )
    fun observeSubjectsWithStats(): Flow<List<SubjectWithStats>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertSubject(subject: SubjectEntity): Long

    @Update
    suspend fun updateSubject(subject: SubjectEntity)

    @Query("DELETE FROM subjects WHERE id = :subjectId")
    suspend fun deleteSubjectById(subjectId: Long)

    // Chapters & Input History
    @Query(
        """
        SELECT c.id, c.subjectId, c.name, c.createdAt,
               (SELECT COUNT(*) FROM mcqs m WHERE m.chapterId = c.id) AS mcqCount,
               (SELECT COUNT(*) FROM mcqs m WHERE m.chapterId = c.id AND m.correctAnswer != 'UNKNOWN') AS validMcqCount
        FROM chapters c
        ORDER BY c.createdAt DESC
        """
    )
    fun observeAllChapters(): Flow<List<ChapterWithCount>>

    @Query(
        """
        SELECT c.id AS chapterId,
               c.subjectId AS subjectId,
               COALESCE(s.name, '') AS subjectName,
               COALESCE(s.iconEmoji, '📘') AS subjectEmoji,
               c.name AS chapterName,
               (SELECT COUNT(*) FROM mcqs m WHERE m.chapterId = c.id) AS mcqCount,
               c.createdAt AS createdAt
        FROM chapters c
        INNER JOIN subjects s ON c.subjectId = s.id
        ORDER BY c.createdAt DESC
        """
    )
    fun observeInputHistory(): Flow<List<InputHistoryItem>>

    @Query("SELECT * FROM chapters WHERE subjectId = :subjectId AND LOWER(TRIM(name)) = LOWER(TRIM(:name)) LIMIT 1")
    suspend fun findChapterByName(subjectId: Long, name: String): ChapterEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertChapter(chapter: ChapterEntity): Long

    @Query("DELETE FROM chapters WHERE id = :chapterId")
    suspend fun deleteChapterById(chapterId: Long)

    @Query("DELETE FROM chapters WHERE id IN (:chapterIds)")
    suspend fun deleteChaptersByIds(chapterIds: List<Long>)

    // MCQs
    @Query("SELECT COUNT(*) FROM mcqs")
    fun observeTotalMcqCount(): Flow<Int>

    @Query("SELECT * FROM mcqs WHERE chapterId = :chapterId ORDER BY id ASC")
    suspend fun getMcqsForChapter(chapterId: Long): List<McqEntity>

    @Query(
        """
        SELECT m.* FROM mcqs m
        INNER JOIN chapters c ON m.chapterId = c.id
        WHERE c.subjectId = :subjectId
        ORDER BY m.id ASC
        """
    )
    suspend fun getMcqsForSubject(subjectId: Long): List<McqEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertMcqs(mcqs: List<McqEntity>)

    @Update
    suspend fun updateMcq(mcq: McqEntity)

    @Query("DELETE FROM mcqs WHERE id = :mcqId")
    suspend fun deleteMcqById(mcqId: Long)

    // Quiz Sessions (Output History)
    @Query(
        """
        SELECT qs.id, qs.subjectId, qs.chapterId, qs.score, qs.total, qs.wrongCount, qs.skippedCount,
               qs.dateTaken, qs.durationSeconds,
               COALESCE(s.name, '') AS subjectName,
               COALESCE(s.iconEmoji, '📘') AS subjectEmoji,
               c.name AS chapterName
        FROM quiz_sessions qs
        LEFT JOIN subjects s ON qs.subjectId = s.id
        LEFT JOIN chapters c ON qs.chapterId = c.id
        ORDER BY qs.dateTaken DESC
        """
    )
    fun observeQuizSessions(): Flow<List<QuizSessionWithMeta>>

    @Query("SELECT COUNT(*) FROM quiz_sessions WHERE dateTaken >= :startOfDayMillis")
    fun observeTodaySessionsCount(startOfDayMillis: Long): Flow<Int>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertQuizSession(session: QuizSessionEntity): Long

    @Query("DELETE FROM quiz_sessions WHERE id IN (:sessionIds)")
    suspend fun deleteSessionsByIds(sessionIds: List<Long>)
}
