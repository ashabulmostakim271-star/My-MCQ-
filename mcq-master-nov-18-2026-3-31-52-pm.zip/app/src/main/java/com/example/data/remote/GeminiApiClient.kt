package com.example.data.remote

import androidx.compose.runtime.Immutable
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlinx.serialization.Serializable
import kotlinx.serialization.json.Json
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.util.UUID
import java.util.concurrent.TimeUnit

@Immutable
data class ExtractedMcqDraft(
    val localId: String = UUID.randomUUID().toString(),
    val question: String,
    val optionA: String,
    val optionB: String,
    val optionC: String,
    val optionD: String,
    val correctAnswer: String, // "A", "B", "C", "D", or "UNKNOWN"
    val explanation: String? = null
)

@Serializable
private data class GeminiMcqJsonItem(
    val question: String = "",
    val optionA: String = "",
    val optionB: String = "",
    val optionC: String = "",
    val optionD: String = "",
    val correctAnswer: String = "UNKNOWN",
    val explanation: String? = null
)

class GeminiApiClient {

    private val client: OkHttpClient = OkHttpClient.Builder()
        .connectTimeout(30, TimeUnit.SECONDS)
        .readTimeout(90, TimeUnit.SECONDS)
        .writeTimeout(60, TimeUnit.SECONDS)
        .build()

    private val json = Json {
        ignoreUnknownKeys = true
        isLenient = true
        coerceInputValues = true
    }

    suspend fun testConnection(apiKey: String): Result<Unit> = withContext(Dispatchers.IO) {
        val trimmed = apiKey.trim()
        if (trimmed.isEmpty()) {
            return@withContext Result.failure(IllegalArgumentException("API Key cannot be empty."))
        }

        runCatching {
            val payload = JSONObject().apply {
                put("contents", JSONArray().apply {
                    put(JSONObject().apply {
                        put("parts", JSONArray().apply {
                            put(JSONObject().put("text", "Reply with OK"))
                        })
                    })
                })
                put("generationConfig", JSONObject().apply {
                    put("maxOutputTokens", 5)
                    put("temperature", 0.0)
                })
            }

            val url = "$BASE_URL/models/$MODEL_NAME:generateContent?key=$trimmed"
            val request = Request.Builder()
                .url(url)
                .post(payload.toString().toRequestBody(JSON_MEDIA_TYPE))
                .build()

            client.newCall(request).execute().use { response ->
                val bodyString = response.body?.string().orEmpty()
                if (!response.isSuccessful) {
                    throw IllegalStateException(parseApiError(response.code, bodyString))
                }
            }
        }
    }

    suspend fun extractMcqs(
        apiKey: String,
        pages: List<EncodedPageImage>,
        onBatchProgress: (currentBatch: Int, totalBatches: Int) -> Unit = { _, _ -> }
    ): Result<List<ExtractedMcqDraft>> = withContext(Dispatchers.IO) {
        val trimmed = apiKey.trim()
        if (trimmed.isEmpty()) {
            return@withContext Result.failure(
                IllegalStateException("Gemini API key is not set. Please add your key in Settings.")
            )
        }
        if (pages.isEmpty()) {
            return@withContext Result.failure(
                IllegalArgumentException("No readable pages or images found.")
            )
        }

        runCatching {
            val batches = pages.chunked(BATCH_SIZE)
            val allDrafts = mutableListOf<ExtractedMcqDraft>()

            batches.forEachIndexed { index, batch ->
                onBatchProgress(index + 1, batches.size)
                val batchDrafts = requestBatchExtraction(trimmed, batch)
                allDrafts.addAll(batchDrafts)
            }

            allDrafts
        }
    }

    private fun requestBatchExtraction(
        apiKey: String,
        batch: List<EncodedPageImage>
    ): List<ExtractedMcqDraft> {
        val parts = JSONArray().apply {
            put(JSONObject().put("text", STRICT_EXTRACTION_PROMPT))
            batch.forEach { page ->
                put(JSONObject().apply {
                    put("inlineData", JSONObject().apply {
                        put("mimeType", page.mimeType)
                        put("data", page.base64Data)
                    })
                })
            }
        }

        val payload = JSONObject().apply {
            put("contents", JSONArray().apply {
                put(JSONObject().apply {
                    put("parts", parts)
                })
            })
            put("generationConfig", JSONObject().apply {
                put("temperature", 0.0)
                put("responseMimeType", "application/json")
            })
        }

        val url = "$BASE_URL/models/$MODEL_NAME:generateContent?key=$apiKey"
        val request = Request.Builder()
            .url(url)
            .post(payload.toString().toRequestBody(JSON_MEDIA_TYPE))
            .build()

        client.newCall(request).execute().use { response ->
            val responseBody = response.body?.string().orEmpty()
            if (!response.isSuccessful) {
                throw IllegalStateException(parseApiError(response.code, responseBody))
            }

            val rawText = extractCandidateText(responseBody)
            return parseMcqJsonArray(rawText)
        }
    }

    private fun extractCandidateText(responseBody: String): String {
        val root = JSONObject(responseBody)
        val candidates = root.optJSONArray("candidates")
            ?: throw IllegalStateException("Gemini returned no candidates.")
        if (candidates.length() == 0) {
            throw IllegalStateException("Gemini returned an empty response.")
        }
        val first = candidates.getJSONObject(0)
        val content = first.optJSONObject("content")
            ?: throw IllegalStateException("Gemini response missing content.")
        val parts = content.optJSONArray("parts")
            ?: throw IllegalStateException("Gemini response missing parts.")

        val sb = StringBuilder()
        for (i in 0 until parts.length()) {
            val part = parts.getJSONObject(i)
            if (part.has("text")) {
                sb.append(part.getString("text"))
            }
        }
        return sb.toString().trim()
    }

    private fun parseMcqJsonArray(rawText: String): List<ExtractedMcqDraft> {
        var cleaned = rawText.trim()
        if (cleaned.startsWith("```")) {
            cleaned = cleaned
                .removePrefix("```json")
                .removePrefix("```JSON")
                .removePrefix("```")
                .removeSuffix("```")
                .trim()
        }
        val startIdx = cleaned.indexOf('[')
        val endIdx = cleaned.lastIndexOf(']')
        if (startIdx >= 0 && endIdx > startIdx) {
            cleaned = cleaned.substring(startIdx, endIdx + 1)
        }

        val parsed: List<GeminiMcqJsonItem> = json.decodeFromString(cleaned)
        return parsed
            .filter { it.question.isNotBlank() }
            .map { item ->
                ExtractedMcqDraft(
                    question = item.question.trim(),
                    optionA = item.optionA.trim(),
                    optionB = item.optionB.trim(),
                    optionC = item.optionC.trim(),
                    optionD = item.optionD.trim(),
                    correctAnswer = normalizeAnswer(item.correctAnswer),
                    explanation = item.explanation?.trim()?.takeIf {
                        it.isNotEmpty() && !it.equals("null", ignoreCase = true)
                    }
                )
            }
    }

    private fun normalizeAnswer(raw: String): String {
        val cleaned = raw.trim().uppercase()
        return when {
            cleaned == "A" || cleaned == "OPTION A" || cleaned == "(A)" || cleaned == "ক" -> "A"
            cleaned == "B" || cleaned == "OPTION B" || cleaned == "(B)" || cleaned == "খ" -> "B"
            cleaned == "C" || cleaned == "OPTION C" || cleaned == "(C)" || cleaned == "গ" -> "C"
            cleaned == "D" || cleaned == "OPTION D" || cleaned == "(D)" || cleaned == "ঘ" -> "D"
            else -> "UNKNOWN"
        }
    }

    private fun parseApiError(code: Int, body: String): String {
        val serverMsg = runCatching {
            JSONObject(body).optJSONObject("error")?.optString("message").orEmpty()
        }.getOrDefault("")
        return when {
            code == 400 && serverMsg.contains("API key", ignoreCase = true) ->
                "Invalid Gemini API Key. Please check your key in Settings."
            code == 401 || code == 403 ->
                "API Key rejected ($code). Verify your Gemini API key at aistudio.google.com."
            code == 429 ->
                "Free tier rate limit reached (429). Please wait a moment and try again."
            serverMsg.isNotBlank() -> "Gemini API error ($code): $serverMsg"
            else -> "Gemini API request failed with HTTP $code."
        }
    }

    companion object {
        const val MODEL_NAME = "gemini-1.5-flash"
        private const val BASE_URL = "https://generativelanguage.googleapis.com/v1beta"
        private const val BATCH_SIZE = 5
        private val JSON_MEDIA_TYPE = "application/json; charset=utf-8".toMediaType()

        private const val STRICT_EXTRACTION_PROMPT = """You are an MCQ extractor. Your ONLY job is to find and extract MCQs that are ALREADY PRESENT in this document.

STRICT RULES:
1. DO NOT create, invent, or generate any new questions or answers.
2. DO NOT guess any answer. Only use answers that are explicitly stated in the document (marked as correct, underlined, in answer key, or indicated in any way).
3. If an answer is not clearly indicated in the source, mark correctAnswer as 'UNKNOWN' — do not guess.
4. Extract the explanation or notes that appear alongside the MCQ in the source document, if any.
5. Preserve the original Bengali or English text exactly as written.

Return ONLY valid JSON array, no extra text:
[
  {
    "question": "...",
    "optionA": "...",
    "optionB": "...",
    "optionC": "...",
    "optionD": "...",
    "correctAnswer": "A" or "B" or "C" or "D" or "UNKNOWN",
    "explanation": "..." or null
  }
]"""
    }
}
