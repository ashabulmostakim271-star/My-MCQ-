package com.example.data.local

import android.content.Context
import androidx.compose.runtime.Immutable
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

private val Context.dataStore: DataStore<Preferences> by preferencesDataStore(name = "mcq_master_settings")

enum class ExplanationMode {
    ALWAYS,
    ON_WRONG_ONLY,
    NEVER
}

enum class AppLanguage {
    ENGLISH,
    BENGALI
}

@Immutable
data class AppPreferences(
    val soundEffectsEnabled: Boolean = true,
    val explanationMode: ExplanationMode = ExplanationMode.ALWAYS,
    val language: AppLanguage = AppLanguage.ENGLISH
)

class PreferencesManager(private val context: Context) {

    val preferencesFlow: Flow<AppPreferences> = context.dataStore.data.map { prefs ->
        val sound = prefs[KEY_SOUND_EFFECTS] ?: true
        val explanationName = prefs[KEY_EXPLANATION_MODE] ?: ExplanationMode.ALWAYS.name
        val languageName = prefs[KEY_LANGUAGE] ?: AppLanguage.ENGLISH.name
        AppPreferences(
            soundEffectsEnabled = sound,
            explanationMode = runCatching { ExplanationMode.valueOf(explanationName) }
                .getOrDefault(ExplanationMode.ALWAYS),
            language = runCatching { AppLanguage.valueOf(languageName) }
                .getOrDefault(AppLanguage.ENGLISH)
        )
    }

    suspend fun setSoundEffects(enabled: Boolean) {
        context.dataStore.edit { it[KEY_SOUND_EFFECTS] = enabled }
    }

    suspend fun setExplanationMode(mode: ExplanationMode) {
        context.dataStore.edit { it[KEY_EXPLANATION_MODE] = mode.name }
    }

    suspend fun setLanguage(language: AppLanguage) {
        context.dataStore.edit { it[KEY_LANGUAGE] = language.name }
    }

    companion object {
        private val KEY_SOUND_EFFECTS = booleanPreferencesKey("sound_effects")
        private val KEY_EXPLANATION_MODE = stringPreferencesKey("explanation_mode")
        private val KEY_LANGUAGE = stringPreferencesKey("app_language")
    }
}
