package com.example.util

import android.media.AudioManager
import android.media.ToneGenerator
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

class SoundEffectHelper {
    private var toneGenerator: ToneGenerator? = null

    private fun getOrCreateToneGenerator(): ToneGenerator? {
        return toneGenerator ?: runCatching {
            ToneGenerator(AudioManager.STREAM_MUSIC, 65).also { toneGenerator = it }
        }.getOrNull()
    }

    fun playCorrect(scope: CoroutineScope) {
        scope.launch(Dispatchers.Default) {
            runCatching {
                getOrCreateToneGenerator()?.startTone(ToneGenerator.TONE_PROP_ACK, 140)
            }
        }
    }

    fun playWrong(scope: CoroutineScope) {
        scope.launch(Dispatchers.Default) {
            runCatching {
                getOrCreateToneGenerator()?.startTone(ToneGenerator.TONE_PROP_NACK, 180)
            }
        }
    }

    fun release() {
        runCatching {
            toneGenerator?.release()
            toneGenerator = null
        }
    }
}
