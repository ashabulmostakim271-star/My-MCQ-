package com.example

import android.app.Application
import com.example.data.local.AppDatabase
import com.example.data.local.PreferencesManager
import com.example.data.local.SecureKeyManager
import com.example.data.remote.DocumentProcessor
import com.example.data.remote.GeminiApiClient
import com.example.data.repository.McqRepository

class McqMasterApplication : Application() {

    val database: AppDatabase by lazy(LazyThreadSafetyMode.SYNCHRONIZED) {
        AppDatabase.getInstance(this)
    }

    val repository: McqRepository by lazy(LazyThreadSafetyMode.SYNCHRONIZED) {
        McqRepository(
            dao = database.mcqDao(),
            secureKeyManager = SecureKeyManager(this),
            preferencesManager = PreferencesManager(this),
            documentProcessor = DocumentProcessor(this),
            geminiApiClient = GeminiApiClient()
        )
    }
}
