package com.example.ui.screens

import android.content.res.Configuration
import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.defaultMinSize
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.filled.Cancel
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Lightbulb
import androidx.compose.material.icons.filled.SkipNext
import androidx.compose.material.icons.outlined.RadioButtonUnchecked
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import com.example.data.local.AppLanguage
import com.example.data.local.ExplanationMode
import com.example.data.local.McqEntity
import com.example.ui.ActiveQuizState
import com.example.ui.components.ElevatedBrandCard
import com.example.ui.components.PrimaryActionButton
import com.example.ui.theme.BorderOutline
import com.example.ui.theme.CorrectGreen
import com.example.ui.theme.CorrectGreenBg
import com.example.ui.theme.MCQMasterTheme
import com.example.ui.theme.OptionTextStyle
import com.example.ui.theme.PrimaryBlue
import com.example.ui.theme.PrimaryBlueLight
import com.example.ui.theme.QuestionTextStyle
import com.example.ui.theme.WrongRed
import com.example.ui.theme.WrongRedBg
import com.example.util.AppStrings
import com.example.util.LocalizedStrings
import kotlinx.coroutines.delay

@Composable
fun QuizScreen(
    quizState: ActiveQuizState?,
    explanationMode: ExplanationMode,
    language: AppLanguage,
    strings: LocalizedStrings,
    onSelectOption: (String) -> Unit,
    onSkipQuestion: () -> Unit,
    onNextQuestion: () -> Unit,
    onExitQuiz: () -> Unit,
    modifier: Modifier = Modifier
) {
    if (quizState == null || quizState.currentQuestion == null) {
        Box(modifier = modifier.fillMaxSize())
        return
    }

    var showExitConfirm by remember { mutableStateOf(false) }
    BackHandler { showExitConfirm = true }

    val current = quizState.currentQuestion!!
    val isCorrect = quizState.isAnswerRevealed &&
        quizState.selectedOption.equals(current.correctAnswer, ignoreCase = true)
    val isWrong = quizState.isAnswerRevealed && !isCorrect

    // Fast 300ms fade-in -> 400ms hold -> 200ms fade-out flash (900ms total)
    val flashAlpha = remember(quizState.currentIndex) { Animatable(0f) }
    LaunchedEffect(quizState.currentIndex, quizState.isAnswerRevealed) {
        if (quizState.isAnswerRevealed) {
            flashAlpha.snapTo(0f)
            flashAlpha.animateTo(1f, animationSpec = tween(durationMillis = 300))
            delay(400L)
            flashAlpha.animateTo(0f, animationSpec = tween(durationMillis = 200))
        } else {
            flashAlpha.snapTo(0f)
        }
    }

    val flashColor = when {
        isCorrect -> CorrectGreenBg.copy(alpha = flashAlpha.value)
        isWrong -> WrongRedBg.copy(alpha = flashAlpha.value)
        else -> Color.Transparent
    }

    val animatedProgress by animateFloatAsState(
        targetValue = (quizState.currentIndex + 1).toFloat() / quizState.totalPlayable.toFloat(),
        animationSpec = tween(durationMillis = 250),
        label = "quiz_progress_anim"
    )

    val listState = rememberLazyListState()
    LaunchedEffect(quizState.currentIndex) {
        listState.scrollToItem(0)
    }

    val options = remember(current.id) {
        listOf(
            "A" to current.optionA,
            "B" to current.optionB,
            "C" to current.optionC,
            "D" to current.optionD
        )
    }

    val shouldShowExplanation = quizState.isAnswerRevealed &&
        !current.explanation.isNullOrBlank() &&
        when (explanationMode) {
            ExplanationMode.ALWAYS -> true
            ExplanationMode.ON_WRONG_ONLY -> isWrong
            ExplanationMode.NEVER -> false
        }

    val isLastQuestion = quizState.currentIndex == quizState.totalPlayable - 1

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .background(flashColor),
        contentAlignment = Alignment.TopCenter
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 16.dp, vertical = 12.dp)
        ) {
            QuizTopProgressHeader(
                currentNumber = quizState.currentIndex + 1,
                totalPlayable = quizState.totalPlayable,
                progress = animatedProgress,
                startTimeMillis = quizState.startTimeMillis,
                strings = strings
            )

            Spacer(Modifier.height(12.dp))

            LazyColumn(
                state = listState,
                modifier = Modifier.weight(1f),
                contentPadding = PaddingValues(bottom = 12.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                item(key = "feedback_banner") {
                    QuizFeedbackBanner(
                        visible = quizState.isAnswerRevealed,
                        isCorrect = isCorrect,
                        language = language
                    )
                }

                item(key = "question_card_${current.id}") {
                    QuestionPromptCard(
                        subjectEmoji = quizState.subjectEmoji,
                        subjectName = quizState.subjectName,
                        chapterName = quizState.chapterName,
                        question = current.question
                    )
                }

                items(options, key = { (optKey, _) -> "${current.id}_$optKey" }) { (key, text) ->
                    QuizOptionRowCard(
                        optionKey = key,
                        optionText = text,
                        isAnswerRevealed = quizState.isAnswerRevealed,
                        isSelectedOption = quizState.selectedOption.equals(key, ignoreCase = true),
                        isTrueAnswer = current.correctAnswer.equals(key, ignoreCase = true),
                        onClick = { onSelectOption(key) }
                    )
                }

                if (shouldShowExplanation) {
                    item(key = "explanation_${current.id}") {
                        QuizExplanationCard(
                            title = strings.explanationTitle,
                            explanation = current.explanation.orEmpty()
                        )
                    }
                }
            }

            Spacer(Modifier.height(8.dp))

            // Smooth slide-up animation for Next button
            AnimatedVisibility(
                visible = quizState.isAnswerRevealed,
                enter = slideInVertically(
                    initialOffsetY = { it / 2 },
                    animationSpec = tween(220)
                ) + fadeIn(tween(220)),
                exit = fadeOut(tween(120))
            ) {
                PrimaryActionButton(
                    text = if (isLastQuestion) strings.finishQuiz else strings.nextQuestion,
                    onClick = onNextQuestion,
                    icon = Icons.AutoMirrored.Filled.ArrowForward,
                    containerColor = if (isCorrect) CorrectGreen else PrimaryBlue,
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("quiz_next_button")
                )
            }

            if (!quizState.isAnswerRevealed) {
                TextButton(
                    onClick = onSkipQuestion,
                    modifier = Modifier
                        .align(Alignment.End)
                        .defaultMinSize(minHeight = 52.dp)
                        .testTag("quiz_skip_button")
                ) {
                    Icon(Icons.Default.SkipNext, contentDescription = null)
                    Spacer(Modifier.width(6.dp))
                    Text(strings.skipQuestion, style = MaterialTheme.typography.labelLarge)
                }
            }
        }
    }

    if (showExitConfirm) {
        AlertDialog(
            onDismissRequest = { showExitConfirm = false },
            containerColor = MaterialTheme.colorScheme.background,
            shape = RoundedCornerShape(16.dp),
            title = { Text(strings.exitQuizTitle) },
            text = { Text(strings.exitQuizBody) },
            confirmButton = {
                Button(
                    onClick = {
                        showExitConfirm = false
                        onExitQuiz()
                    },
                    shape = RoundedCornerShape(12.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = WrongRed),
                    modifier = Modifier.defaultMinSize(minHeight = 48.dp)
                ) {
                    Text(strings.exit)
                }
            },
            dismissButton = {
                TextButton(
                    onClick = { showExitConfirm = false },
                    modifier = Modifier.defaultMinSize(minHeight = 48.dp)
                ) {
                    Text(strings.stay)
                }
            }
        )
    }
}

@Composable
private fun QuizTopProgressHeader(
    currentNumber: Int,
    totalPlayable: Int,
    progress: Float,
    startTimeMillis: Long,
    strings: LocalizedStrings
) {
    var elapsedSeconds by remember(startTimeMillis) { mutableLongStateOf(0L) }
    LaunchedEffect(startTimeMillis) {
        while (true) {
            elapsedSeconds = (System.currentTimeMillis() - startTimeMillis) / 1000L
            delay(1000L)
        }
    }

    Column {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = strings.progressLabel(currentNumber, totalPlayable),
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onBackground
            )
            Surface(
                shape = RoundedCornerShape(10.dp),
                color = PrimaryBlueLight
            ) {
                val mins = elapsedSeconds / 60
                val secs = elapsedSeconds % 60
                Text(
                    text = String.format("%02d:%02d", mins, secs),
                    style = MaterialTheme.typography.labelMedium,
                    color = PrimaryBlue,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 5.dp)
                )
            }
        }
        Spacer(Modifier.height(8.dp))
        LinearProgressIndicator(
            progress = { progress },
            color = PrimaryBlue,
            trackColor = BorderOutline,
            modifier = Modifier
                .fillMaxWidth()
                .height(8.dp)
        )
    }
}

@Composable
private fun QuizFeedbackBanner(
    visible: Boolean,
    isCorrect: Boolean,
    language: AppLanguage
) {
    val feedbackScale by animateFloatAsState(
        targetValue = if (visible) 1f else 0.85f,
        animationSpec = spring(
            dampingRatio = Spring.DampingRatioMediumBouncy,
            stiffness = Spring.StiffnessMedium
        ),
        label = "feedback_scale"
    )

    AnimatedVisibility(
        visible = visible,
        enter = fadeIn(tween(180)) + slideInVertically { -it / 2 },
        exit = fadeOut(tween(120))
    ) {
        val bannerColor = if (isCorrect) CorrectGreen else WrongRed
        val feedbackText = when {
            isCorrect && language == AppLanguage.BENGALI -> "সঠিক!"
            isCorrect -> "Correct!"
            language == AppLanguage.BENGALI -> "ভুল হয়েছে"
            else -> "Wrong!"
        }
        Surface(
            shape = RoundedCornerShape(16.dp),
            color = bannerColor,
            shadowElevation = 3.dp,
            modifier = Modifier
                .fillMaxWidth()
                .scale(feedbackScale)
                .testTag("quiz_feedback_banner")
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 18.dp, vertical = 14.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.Center
            ) {
                Icon(
                    imageVector = if (isCorrect) Icons.Default.CheckCircle else Icons.Default.Cancel,
                    contentDescription = feedbackText,
                    tint = Color.White,
                    modifier = Modifier.size(32.dp)
                )
                Spacer(Modifier.width(12.dp))
                Text(
                    text = feedbackText,
                    style = MaterialTheme.typography.headlineSmall,
                    color = Color.White,
                    fontWeight = FontWeight.Bold
                )
            }
        }
    }
}

@Composable
private fun QuestionPromptCard(
    subjectEmoji: String,
    subjectName: String,
    chapterName: String?,
    question: String
) {
    ElevatedBrandCard(
        containerColor = MaterialTheme.colorScheme.background,
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(18.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Text(
                text = "$subjectEmoji $subjectName" + (chapterName?.let { " • $it" } ?: ""),
                style = MaterialTheme.typography.labelMedium,
                color = MaterialTheme.colorScheme.secondary
            )
            Text(
                text = question,
                style = QuestionTextStyle,
                color = MaterialTheme.colorScheme.onBackground,
                modifier = Modifier.testTag("quiz_question_text")
            )
        }
    }
}

@Composable
private fun QuizOptionRowCard(
    optionKey: String,
    optionText: String,
    isAnswerRevealed: Boolean,
    isSelectedOption: Boolean,
    isTrueAnswer: Boolean,
    onClick: () -> Unit
) {
    val cardBg = when {
        !isAnswerRevealed -> MaterialTheme.colorScheme.surface
        isTrueAnswer -> CorrectGreenBg
        isSelectedOption && !isTrueAnswer -> WrongRedBg
        else -> MaterialTheme.colorScheme.surface
    }
    val borderColor = when {
        !isAnswerRevealed -> BorderOutline
        isTrueAnswer -> CorrectGreen
        isSelectedOption && !isTrueAnswer -> WrongRed
        else -> BorderOutline.copy(alpha = 0.6f)
    }
    val textColor = when {
        !isAnswerRevealed -> MaterialTheme.colorScheme.onBackground
        isTrueAnswer -> CorrectGreen
        isSelectedOption && !isTrueAnswer -> WrongRed
        else -> MaterialTheme.colorScheme.onSurfaceVariant
    }

    Card(
        onClick = onClick,
        enabled = !isAnswerRevealed,
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(
            containerColor = cardBg,
            disabledContainerColor = cardBg
        ),
        border = BorderStroke(
            width = if (isAnswerRevealed && (isTrueAnswer || isSelectedOption)) 2.dp else 1.dp,
            color = borderColor
        ),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
        modifier = Modifier
            .fillMaxWidth()
            .defaultMinSize(minHeight = 56.dp)
            .testTag("quiz_option_$optionKey")
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 14.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            when {
                isAnswerRevealed && isTrueAnswer -> {
                    Icon(
                        imageVector = Icons.Default.CheckCircle,
                        contentDescription = "Correct option",
                        tint = CorrectGreen,
                        modifier = Modifier.size(22.dp)
                    )
                }
                isAnswerRevealed && isSelectedOption && !isTrueAnswer -> {
                    Icon(
                        imageVector = Icons.Default.Cancel,
                        contentDescription = "Wrong option",
                        tint = WrongRed,
                        modifier = Modifier.size(22.dp)
                    )
                }
                else -> {
                    Icon(
                        imageVector = Icons.Outlined.RadioButtonUnchecked,
                        contentDescription = null,
                        tint = PrimaryBlue,
                        modifier = Modifier.size(22.dp)
                    )
                }
            }
            Spacer(Modifier.width(12.dp))
            Text(
                text = "$optionKey. $optionText",
                style = OptionTextStyle,
                fontWeight = if (isAnswerRevealed && isTrueAnswer) FontWeight.Bold else FontWeight.Normal,
                color = textColor,
                modifier = Modifier.weight(1f)
            )
        }
    }
}

@Composable
private fun QuizExplanationCard(
    title: String,
    explanation: String
) {
    ElevatedBrandCard(
        containerColor = MaterialTheme.colorScheme.background,
        border = BorderStroke(1.dp, PrimaryBlue.copy(alpha = 0.4f)),
        modifier = Modifier
            .fillMaxWidth()
            .testTag("quiz_explanation_card")
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp),
            verticalAlignment = Alignment.Top
        ) {
            Surface(
                shape = CircleShape,
                color = PrimaryBlueLight,
                modifier = Modifier.size(34.dp)
            ) {
                Box(contentAlignment = Alignment.Center) {
                    Icon(
                        imageVector = Icons.Default.Lightbulb,
                        contentDescription = null,
                        tint = PrimaryBlue,
                        modifier = Modifier.size(18.dp)
                    )
                }
            }
            Spacer(Modifier.width(10.dp))
            Column {
                Text(
                    text = title,
                    style = MaterialTheme.typography.titleSmall,
                    color = PrimaryBlue
                )
                Spacer(Modifier.height(4.dp))
                Text(
                    text = explanation,
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onBackground
                )
            }
        }
    }
}

@Preview(
    showBackground = true,
    showSystemUi = true,
    device = "spec:width=360dp,height=800dp,dpi=420",
    uiMode = Configuration.UI_MODE_NIGHT_NO
)
@Composable
private fun QuizScreenPreview() {
    MCQMasterTheme {
        QuizScreen(
            quizState = ActiveQuizState(
                subjectId = 1L,
                subjectName = "পদার্থবিজ্ঞান",
                subjectEmoji = "⚛️",
                chapterName = "অধ্যায় ৩: বল",
                questions = listOf(
                    McqEntity(
                        id = 1L,
                        chapterId = 1L,
                        question = "বলের SI একক কোনটি?",
                        optionA = "জুল",
                        optionB = "নিউটন",
                        optionC = "ওয়াট",
                        optionD = "প্যাসকেল",
                        correctAnswer = "B"
                    )
                )
            ),
            explanationMode = ExplanationMode.ALWAYS,
            language = AppLanguage.ENGLISH,
            strings = AppStrings.get(AppLanguage.ENGLISH),
            onSelectOption = {},
            onSkipQuestion = {},
            onNextQuestion = {},
            onExitQuiz = {}
        )
    }
}
