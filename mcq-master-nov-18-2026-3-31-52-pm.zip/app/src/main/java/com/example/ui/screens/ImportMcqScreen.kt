package com.example.ui.screens

import android.content.res.Configuration
import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.defaultMinSize
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.DeleteOutline
import androidx.compose.material.icons.filled.Description
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Image
import androidx.compose.material.icons.filled.PictureAsPdf
import androidx.compose.material.icons.filled.Save
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExposedDropdownMenuBox
import androidx.compose.material3.ExposedDropdownMenuDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.MenuAnchorType
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.SuggestionChip
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import com.example.data.local.ApiKeyStatus
import com.example.data.local.AppLanguage
import com.example.data.local.ChapterWithCount
import com.example.data.local.SubjectWithStats
import com.example.data.remote.ExtractedMcqDraft
import com.example.data.remote.SourceFileType
import com.example.ui.ImportUiState
import com.example.ui.components.AddOrEditSubjectDialog
import com.example.ui.components.ElevatedBrandCard
import com.example.ui.components.PrimaryActionButton
import com.example.ui.theme.BorderOutline
import com.example.ui.theme.CorrectGreen
import com.example.ui.theme.CorrectGreenBg
import com.example.ui.theme.MCQMasterTheme
import com.example.ui.theme.PrimaryBlue
import com.example.ui.theme.PrimaryBlueLight
import com.example.ui.theme.SecondaryTeal
import com.example.ui.theme.WarningOrange
import com.example.ui.theme.WarningOrangeBg
import com.example.ui.theme.WrongRed
import com.example.ui.theme.WrongRedBg
import com.example.util.AppStrings
import com.example.util.LocalizedStrings

@OptIn(ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class)
@Composable
fun ImportMcqScreen(
    importState: ImportUiState,
    subjects: List<SubjectWithStats>,
    allChapters: List<ChapterWithCount>,
    apiStatus: ApiKeyStatus,
    strings: LocalizedStrings,
    onSelectSubject: (Long) -> Unit,
    onCreateSubject: (name: String, emoji: String) -> Unit,
    onChapterNameChange: (String) -> Unit,
    onFilePicked: (Uri, SourceFileType) -> Unit,
    onExtractClick: () -> Unit,
    onUpdateDraft: (ExtractedMcqDraft) -> Unit,
    onDeleteDraft: (String) -> Unit,
    onSaveMcqs: () -> Unit,
    onOpenSettings: () -> Unit,
    modifier: Modifier = Modifier
) {
    var subjectDropdownExpanded by remember { mutableStateOf(false) }
    var showCreateSubjectDialog by remember { mutableStateOf(false) }
    var editingDraft by remember { mutableStateOf<ExtractedMcqDraft?>(null) }

    val pdfLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocument()
    ) { uri ->
        if (uri != null) onFilePicked(uri, SourceFileType.PDF)
    }

    val imageLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickVisualMedia()
    ) { uri ->
        if (uri != null) onFilePicked(uri, SourceFileType.IMAGE)
    }

    val selectedSubject = subjects.find { it.id == importState.selectedSubjectId }
    val matchingChapters = remember(importState.selectedSubjectId, allChapters) {
        allChapters.filter { it.subjectId == importState.selectedSubjectId }
    }
    val unknownCount = remember(importState.extractedDrafts) {
        importState.extractedDrafts.count { it.correctAnswer == "UNKNOWN" }
    }

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background),
        contentAlignment = Alignment.TopCenter
    ) {
        Column(modifier = Modifier.fillMaxSize()) {
            LazyColumn(
                modifier = Modifier.weight(1f),
                contentPadding = PaddingValues(16.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                if (apiStatus == ApiKeyStatus.NOT_SET) {
                    item {
                        ElevatedBrandCard(
                            containerColor = WarningOrangeBg,
                            border = BorderStroke(1.dp, WarningOrange.copy(alpha = 0.5f))
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(14.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Icon(Icons.Default.Warning, contentDescription = null, tint = WarningOrange)
                                Spacer(Modifier.width(10.dp))
                                Text(
                                    text = strings.apiBannerMissing,
                                    style = MaterialTheme.typography.bodySmall,
                                    modifier = Modifier.weight(1f)
                                )
                                TextButton(onClick = onOpenSettings) {
                                    Text(strings.openSettings, fontWeight = FontWeight.Bold)
                                }
                            }
                        }
                    }
                }

                // Step 1: Select Subject
                item {
                    ElevatedBrandCard {
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(16.dp),
                            verticalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            Text(
                                text = strings.step1SelectSubject,
                                style = MaterialTheme.typography.titleMedium,
                                color = PrimaryBlue
                            )
                            if (subjects.isEmpty()) {
                                Text(
                                    text = strings.noSubjectsImportHint,
                                    style = MaterialTheme.typography.bodyMedium,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                                PrimaryActionButton(
                                    text = strings.createSubjectNow,
                                    onClick = { showCreateSubjectDialog = true },
                                    modifier = Modifier.fillMaxWidth()
                                )
                            } else {
                                ExposedDropdownMenuBox(
                                    expanded = subjectDropdownExpanded,
                                    onExpandedChange = { subjectDropdownExpanded = !subjectDropdownExpanded }
                                ) {
                                    OutlinedTextField(
                                        value = selectedSubject?.let { "${it.iconEmoji} ${it.name}" } ?: "",
                                        onValueChange = {},
                                        readOnly = true,
                                        placeholder = { Text(strings.selectSubject) },
                                        trailingIcon = {
                                            ExposedDropdownMenuDefaults.TrailingIcon(expanded = subjectDropdownExpanded)
                                        },
                                        shape = RoundedCornerShape(12.dp),
                                        modifier = Modifier
                                            .menuAnchor(MenuAnchorType.PrimaryNotEditable)
                                            .fillMaxWidth()
                                            .testTag("import_subject_dropdown")
                                    )
                                    ExposedDropdownMenu(
                                        expanded = subjectDropdownExpanded,
                                        onDismissRequest = { subjectDropdownExpanded = false },
                                        containerColor = MaterialTheme.colorScheme.background
                                    ) {
                                        subjects.forEach { subj ->
                                            DropdownMenuItem(
                                                text = { Text("${subj.iconEmoji} ${subj.name}") },
                                                onClick = {
                                                    onSelectSubject(subj.id)
                                                    subjectDropdownExpanded = false
                                                },
                                                modifier = Modifier.heightIn(min = 52.dp)
                                            )
                                        }
                                    }
                                }
                                TextButton(
                                    onClick = { showCreateSubjectDialog = true },
                                    modifier = Modifier.align(Alignment.End)
                                ) {
                                    Text(strings.createSubjectNow)
                                }
                            }
                        }
                    }
                }

                // Step 2: Enter Chapter Name
                item {
                    ElevatedBrandCard {
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(16.dp),
                            verticalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            Text(
                                text = strings.step2ChapterName,
                                style = MaterialTheme.typography.titleMedium,
                                color = PrimaryBlue
                            )
                            OutlinedTextField(
                                value = importState.chapterName,
                                onValueChange = onChapterNameChange,
                                placeholder = { Text(strings.chapterPlaceholder) },
                                singleLine = true,
                                shape = RoundedCornerShape(12.dp),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .testTag("import_chapter_input")
                            )
                            if (matchingChapters.isNotEmpty()) {
                                Text(
                                    text = strings.existingChaptersHint,
                                    style = MaterialTheme.typography.labelMedium,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                                FlowRow(
                                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                                    verticalArrangement = Arrangement.spacedBy(6.dp)
                                ) {
                                    matchingChapters.forEach { chapter ->
                                        SuggestionChip(
                                            onClick = { onChapterNameChange(chapter.name) },
                                            label = { Text(chapter.name) }
                                        )
                                    }
                                }
                            }
                        }
                    }
                }

                // Step 3: Upload Source File
                item {
                    ElevatedBrandCard {
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(16.dp),
                            verticalArrangement = Arrangement.spacedBy(12.dp)
                        ) {
                            Text(
                                text = strings.step3UploadSource,
                                style = MaterialTheme.typography.titleMedium,
                                color = PrimaryBlue
                            )
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(10.dp)
                            ) {
                                OutlinedButton(
                                    onClick = { pdfLauncher.launch(arrayOf("application/pdf")) },
                                    shape = RoundedCornerShape(12.dp),
                                    border = BorderStroke(1.5.dp, PrimaryBlue),
                                    modifier = Modifier
                                        .weight(1f)
                                        .defaultMinSize(minHeight = 60.dp)
                                        .testTag("upload_pdf_button")
                                ) {
                                    Column(
                                        horizontalAlignment = Alignment.CenterHorizontally,
                                        modifier = Modifier.padding(vertical = 4.dp)
                                    ) {
                                        Icon(
                                            imageVector = Icons.Default.PictureAsPdf,
                                            contentDescription = strings.uploadPdf,
                                            tint = WrongRed
                                        )
                                        Spacer(Modifier.height(4.dp))
                                        Text(
                                            text = strings.uploadPdf,
                                            style = MaterialTheme.typography.labelMedium,
                                            color = MaterialTheme.colorScheme.onBackground
                                        )
                                    }
                                }

                                OutlinedButton(
                                    onClick = {
                                        imageLauncher.launch(
                                            PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)
                                        )
                                    },
                                    shape = RoundedCornerShape(12.dp),
                                    border = BorderStroke(1.5.dp, SecondaryTeal),
                                    modifier = Modifier
                                        .weight(1f)
                                        .defaultMinSize(minHeight = 60.dp)
                                        .testTag("upload_image_button")
                                ) {
                                    Column(
                                        horizontalAlignment = Alignment.CenterHorizontally,
                                        modifier = Modifier.padding(vertical = 4.dp)
                                    ) {
                                        Icon(
                                            imageVector = Icons.Default.Image,
                                            contentDescription = strings.uploadImage,
                                            tint = SecondaryTeal
                                        )
                                        Spacer(Modifier.height(4.dp))
                                        Text(
                                            text = strings.uploadImage,
                                            style = MaterialTheme.typography.labelMedium,
                                            color = MaterialTheme.colorScheme.onBackground
                                        )
                                    }
                                }
                            }

                            importState.pickedDocument?.let { doc ->
                                Surface(
                                    shape = RoundedCornerShape(12.dp),
                                    color = PrimaryBlueLight,
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    Row(
                                        modifier = Modifier.padding(12.dp),
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Icon(
                                            imageVector = Icons.Default.Description,
                                            contentDescription = null,
                                            tint = PrimaryBlue
                                        )
                                        Spacer(Modifier.width(10.dp))
                                        Column(modifier = Modifier.weight(1f)) {
                                            Text(
                                                text = "${strings.selectedFileLabel}: ${doc.displayName}",
                                                style = MaterialTheme.typography.bodyMedium,
                                                fontWeight = FontWeight.SemiBold,
                                                color = MaterialTheme.colorScheme.onBackground
                                            )
                                            if (doc.type == SourceFileType.PDF) {
                                                Text(
                                                    text = strings.pagesCount(doc.pageCount),
                                                    style = MaterialTheme.typography.bodySmall,
                                                    color = PrimaryBlue
                                                )
                                            }
                                        }
                                        Icon(
                                            imageVector = Icons.Default.CheckCircle,
                                            contentDescription = null,
                                            tint = CorrectGreen
                                        )
                                    }
                                }
                            }
                        }
                    }
                }

                // Step 4: Extract button
                item {
                    val canExtract = importState.selectedSubjectId != null &&
                        importState.chapterName.isNotBlank() &&
                        importState.pickedDocument != null &&
                        !importState.isExtracting

                    PrimaryActionButton(
                        text = strings.extractButton,
                        onClick = onExtractClick,
                        enabled = canExtract,
                        icon = Icons.Default.AutoAwesome,
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("extract_mcqs_button")
                    )
                }

                // Animated Extraction Progress Card
                if (importState.isExtracting) {
                    item {
                        GeminiExtractingCard(
                            strings = strings,
                            progressDetail = importState.extractionProgressText
                        )
                    }
                }

                // Error Message
                if (importState.errorMessage != null) {
                    item {
                        Surface(
                            shape = RoundedCornerShape(12.dp),
                            color = WrongRedBg,
                            border = BorderStroke(1.dp, WrongRed.copy(alpha = 0.4f)),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text(
                                text = importState.errorMessage,
                                color = WrongRed,
                                style = MaterialTheme.typography.bodyMedium,
                                modifier = Modifier.padding(14.dp)
                            )
                        }
                    }
                }

                // Extracted Preview List
                if (importState.extractedDrafts.isNotEmpty()) {
                    item {
                        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            Text(
                                text = strings.extractedPreviewTitle(importState.extractedDrafts.size),
                                style = MaterialTheme.typography.titleLarge,
                                color = MaterialTheme.colorScheme.onBackground
                            )
                            if (unknownCount > 0) {
                                Surface(
                                    shape = RoundedCornerShape(12.dp),
                                    color = WarningOrangeBg,
                                    border = BorderStroke(1.dp, WarningOrange),
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    Row(
                                        modifier = Modifier.padding(12.dp),
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Icon(
                                            imageVector = Icons.Default.Warning,
                                            contentDescription = null,
                                            tint = WarningOrange
                                        )
                                        Spacer(Modifier.width(8.dp))
                                        Text(
                                            text = strings.unknownCountBanner(unknownCount),
                                            style = MaterialTheme.typography.bodySmall,
                                            color = Color(0xFFBF360C),
                                            fontWeight = FontWeight.SemiBold
                                        )
                                    }
                                }
                            }
                        }
                    }

                    itemsIndexed(
                        items = importState.extractedDrafts,
                        key = { _, item -> item.localId }
                    ) { index, draft ->
                        ExtractedMcqPreviewCard(
                            index = index + 1,
                            draft = draft,
                            strings = strings,
                            onEdit = { editingDraft = draft },
                            onDelete = { onDeleteDraft(draft.localId) }
                        )
                    }
                }
            }

            // Sticky Save Button at Bottom when drafts exist
            AnimatedVisibility(visible = importState.extractedDrafts.isNotEmpty()) {
                Surface(
                    shadowElevation = 8.dp,
                    color = MaterialTheme.colorScheme.background,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    PrimaryActionButton(
                        text = strings.saveMcqsToChapter(importState.extractedDrafts.size),
                        onClick = onSaveMcqs,
                        enabled = !importState.isSaving &&
                            importState.selectedSubjectId != null &&
                            importState.chapterName.isNotBlank(),
                        icon = Icons.Default.Save,
                        containerColor = CorrectGreen,
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(16.dp)
                            .testTag("save_extracted_mcqs_button")
                    )
                }
            }
        }
    }

    if (showCreateSubjectDialog) {
        AddOrEditSubjectDialog(
            strings = strings,
            onDismiss = { showCreateSubjectDialog = false },
            onConfirm = { name, emoji ->
                onCreateSubject(name, emoji)
                showCreateSubjectDialog = false
            }
        )
    }

    editingDraft?.let { draft ->
        EditExtractedMcqDialog(
            draft = draft,
            strings = strings,
            onDismiss = { editingDraft = null },
            onSave = { updated ->
                onUpdateDraft(updated)
                editingDraft = null
            }
        )
    }
}

@Composable
private fun GeminiExtractingCard(
    strings: LocalizedStrings,
    progressDetail: String
) {
    val infiniteTransition = rememberInfiniteTransition(label = "gemini_pulse")
    val alpha by infiniteTransition.animateFloat(
        initialValue = 0.55f,
        targetValue = 1.0f,
        animationSpec = infiniteRepeatable(
            animation = tween(750),
            repeatMode = RepeatMode.Reverse
        ),
        label = "pulse_alpha"
    )

    ElevatedBrandCard(
        containerColor = PrimaryBlueLight,
        border = BorderStroke(1.5.dp, PrimaryBlue.copy(alpha = 0.5f)),
        modifier = Modifier
            .fillMaxWidth()
            .testTag("gemini_extracting_card")
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(18.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(
                    imageVector = Icons.Default.AutoAwesome,
                    contentDescription = null,
                    tint = PrimaryBlue,
                    modifier = Modifier
                        .size(26.dp)
                        .alpha(alpha)
                )
                Spacer(Modifier.width(10.dp))
                Column {
                    Text(
                        text = strings.geminiReadingTitle,
                        style = MaterialTheme.typography.titleMedium,
                        color = PrimaryBlue,
                        fontWeight = FontWeight.Bold
                    )
                    if (progressDetail.isNotBlank()) {
                        Text(
                            text = progressDetail,
                            style = MaterialTheme.typography.labelMedium,
                            color = SecondaryTeal
                        )
                    }
                }
            }
            LinearProgressIndicator(
                modifier = Modifier.fillMaxWidth(),
                color = PrimaryBlue,
                trackColor = Color.White
            )
            Text(
                text = strings.geminiReadingSubtitle,
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
    }
}

@Composable
private fun ExtractedMcqPreviewCard(
    index: Int,
    draft: ExtractedMcqDraft,
    strings: LocalizedStrings,
    onEdit: () -> Unit,
    onDelete: () -> Unit
) {
    val isUnknown = draft.correctAnswer == "UNKNOWN"
    ElevatedBrandCard(
        containerColor = if (isUnknown) WarningOrangeBg else MaterialTheme.colorScheme.surface,
        border = BorderStroke(
            width = if (isUnknown) 1.5.dp else 1.dp,
            color = if (isUnknown) WarningOrange else BorderOutline
        ),
        modifier = Modifier
            .fillMaxWidth()
            .testTag("extracted_mcq_card_$index")
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.Top
            ) {
                Text(
                    text = "$index. ${draft.question}",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onBackground,
                    modifier = Modifier.weight(1f)
                )
                IconButton(
                    onClick = onEdit,
                    modifier = Modifier
                        .size(48.dp)
                        .testTag("edit_draft_button_$index")
                ) {
                    Icon(
                        imageVector = Icons.Default.Edit,
                        contentDescription = "Edit MCQ",
                        tint = PrimaryBlue
                    )
                }
                IconButton(
                    onClick = onDelete,
                    modifier = Modifier
                        .size(48.dp)
                        .testTag("delete_draft_button_$index")
                ) {
                    Icon(
                        imageVector = Icons.Default.DeleteOutline,
                        contentDescription = "Delete MCQ",
                        tint = WrongRed
                    )
                }
            }

            Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                DraftOptionRow("A", draft.optionA, draft.correctAnswer == "A")
                DraftOptionRow("B", draft.optionB, draft.correctAnswer == "B")
                DraftOptionRow("C", draft.optionC, draft.correctAnswer == "C")
                DraftOptionRow("D", draft.optionD, draft.correctAnswer == "D")
            }

            if (isUnknown) {
                Surface(
                    shape = RoundedCornerShape(8.dp),
                    color = WarningOrange.copy(alpha = 0.14f)
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = Icons.Default.Warning,
                            contentDescription = null,
                            tint = WarningOrange,
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(Modifier.width(6.dp))
                        Text(
                            text = strings.unknownAnswerWarning,
                            style = MaterialTheme.typography.labelMedium,
                            color = Color(0xFFBF360C)
                        )
                    }
                }
            }

            if (!draft.explanation.isNullOrBlank()) {
                Text(
                    text = "${strings.explanationTitle}: ${draft.explanation}",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }
    }
}

@Composable
private fun DraftOptionRow(label: String, text: String, isCorrect: Boolean) {
    Row(
        verticalAlignment = Alignment.CenterVertically,
        modifier = Modifier
            .fillMaxWidth()
            .background(
                color = if (isCorrect) CorrectGreenBg else Color.Transparent,
                shape = RoundedCornerShape(8.dp)
            )
            .padding(horizontal = 8.dp, vertical = 4.dp)
    ) {
        Text(
            text = "$label. $text",
            style = MaterialTheme.typography.bodyMedium,
            fontWeight = if (isCorrect) FontWeight.Bold else FontWeight.Normal,
            color = if (isCorrect) CorrectGreen else MaterialTheme.colorScheme.onBackground,
            modifier = Modifier.weight(1f)
        )
        if (isCorrect) {
            Icon(
                imageVector = Icons.Default.CheckCircle,
                contentDescription = "Correct",
                tint = CorrectGreen,
                modifier = Modifier.size(16.dp)
            )
        }
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun EditExtractedMcqDialog(
    draft: ExtractedMcqDraft,
    strings: LocalizedStrings,
    onDismiss: () -> Unit,
    onSave: (ExtractedMcqDraft) -> Unit
) {
    var question by remember { mutableStateOf(draft.question) }
    var optA by remember { mutableStateOf(draft.optionA) }
    var optB by remember { mutableStateOf(draft.optionB) }
    var optC by remember { mutableStateOf(draft.optionC) }
    var optD by remember { mutableStateOf(draft.optionD) }
    var correct by remember { mutableStateOf(draft.correctAnswer) }
    var explanation by remember { mutableStateOf(draft.explanation.orEmpty()) }

    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = MaterialTheme.colorScheme.background,
        shape = RoundedCornerShape(16.dp),
        title = { Text(strings.editMcqTitle, style = MaterialTheme.typography.headlineSmall) },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                OutlinedTextField(
                    value = question,
                    onValueChange = { question = it },
                    label = { Text(strings.questionLabel) },
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = optA,
                    onValueChange = { optA = it },
                    label = { Text("Option A") },
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = optB,
                    onValueChange = { optB = it },
                    label = { Text("Option B") },
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = optC,
                    onValueChange = { optC = it },
                    label = { Text("Option C") },
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = optD,
                    onValueChange = { optD = it },
                    label = { Text("Option D") },
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier.fillMaxWidth()
                )

                Text(
                    text = strings.correctAnswerLabel,
                    style = MaterialTheme.typography.labelMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                FlowRow(
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    listOf("A", "B", "C", "D", "UNKNOWN").forEach { ans ->
                        FilterChip(
                            selected = correct == ans,
                            onClick = { correct = ans },
                            label = { Text(ans) },
                            modifier = Modifier.heightIn(min = 44.dp)
                        )
                    }
                }

                OutlinedTextField(
                    value = explanation,
                    onValueChange = { explanation = it },
                    label = { Text(strings.explanationLabel) },
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier.fillMaxWidth()
                )
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    onSave(
                        draft.copy(
                            question = question.trim(),
                            optionA = optA.trim(),
                            optionB = optB.trim(),
                            optionC = optC.trim(),
                            optionD = optD.trim(),
                            correctAnswer = correct,
                            explanation = explanation.trim().takeIf { it.isNotEmpty() }
                        )
                    )
                },
                enabled = question.isNotBlank(),
                shape = RoundedCornerShape(12.dp),
                colors = ButtonDefaults.buttonColors(containerColor = PrimaryBlue),
                modifier = Modifier.defaultMinSize(minHeight = 48.dp)
            ) {
                Text(strings.save)
            }
        },
        dismissButton = {
            TextButton(
                onClick = onDismiss,
                modifier = Modifier.defaultMinSize(minHeight = 48.dp)
            ) {
                Text(strings.cancel)
            }
        }
    )
}

@Preview(
    showBackground = true,
    showSystemUi = true,
    device = "spec:width=360dp,height=800dp,dpi=420",
    uiMode = Configuration.UI_MODE_NIGHT_NO
)
@Composable
private fun ImportMcqScreenPreview() {
    MCQMasterTheme {
        ImportMcqScreen(
            importState = ImportUiState(selectedSubjectId = 1L, chapterName = "Chapter 1"),
            subjects = listOf(SubjectWithStats(1L, "Physics", "⚛️", 1, 10)),
            allChapters = emptyList(),
            apiStatus = ApiKeyStatus.CONNECTED,
            strings = AppStrings.get(AppLanguage.ENGLISH),
            onSelectSubject = {},
            onCreateSubject = { _, _ -> },
            onChapterNameChange = {},
            onFilePicked = { _, _ -> },
            onExtractClick = {},
            onUpdateDraft = {},
            onDeleteDraft = {},
            onSaveMcqs = {},
            onOpenSettings = {}
        )
    }
}
