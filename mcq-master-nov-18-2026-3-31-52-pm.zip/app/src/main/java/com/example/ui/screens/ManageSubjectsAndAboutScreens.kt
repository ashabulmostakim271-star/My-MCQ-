package com.example.ui.screens

import android.content.res.Configuration
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.defaultMinSize
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.DeleteOutline
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.ExpandLess
import androidx.compose.material.icons.filled.ExpandMore
import androidx.compose.material.icons.filled.School
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.local.AppLanguage
import com.example.data.local.ChapterWithCount
import com.example.data.local.SubjectWithStats
import com.example.ui.components.AddOrEditSubjectDialog
import com.example.ui.components.ElevatedBrandCard
import com.example.ui.components.PrimaryActionButton
import com.example.ui.theme.BorderOutline
import com.example.ui.theme.MCQMasterTheme
import com.example.ui.theme.PrimaryBlue
import com.example.ui.theme.PrimaryBlueLight
import com.example.ui.theme.WrongRed
import com.example.util.AppStrings
import com.example.util.LocalizedStrings

@Composable
fun ManageSubjectsScreen(
    subjects: List<SubjectWithStats>,
    allChapters: List<ChapterWithCount>,
    strings: LocalizedStrings,
    onAddSubject: (name: String, emoji: String) -> Unit,
    onUpdateSubject: (id: Long, name: String, emoji: String) -> Unit,
    onDeleteSubject: (Long) -> Unit,
    onDeleteChapter: (Long) -> Unit,
    modifier: Modifier = Modifier
) {
    var showAddDialog by remember { mutableStateOf(false) }
    var editingSubject by remember { mutableStateOf<SubjectWithStats?>(null) }
    var deletingSubject by remember { mutableStateOf<SubjectWithStats?>(null) }
    var expandedSubjectId by remember { mutableStateOf<Long?>(null) }

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background),
        contentAlignment = Alignment.TopCenter
    ) {
        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            item {
                PrimaryActionButton(
                    text = strings.addSubject,
                    onClick = { showAddDialog = true },
                    icon = Icons.Default.Add,
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("manage_add_subject_button")
                )
            }

            items(subjects, key = { it.id }) { subject ->
                val isExpanded = expandedSubjectId == subject.id
                val chapters = allChapters.filter { it.subjectId == subject.id }

                ElevatedBrandCard(modifier = Modifier.fillMaxWidth()) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(14.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(44.dp)
                                    .background(PrimaryBlueLight, RoundedCornerShape(12.dp)),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(subject.iconEmoji, fontSize = 22.sp)
                            }
                            Spacer(Modifier.width(12.dp))
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = subject.name,
                                    style = MaterialTheme.typography.titleMedium,
                                    fontWeight = FontWeight.Bold
                                )
                                Text(
                                    text = "${strings.chaptersCount(subject.chapterCount)} • ${strings.mcqsCount(subject.mcqCount)}",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                            IconButton(
                                onClick = { expandedSubjectId = if (isExpanded) null else subject.id },
                                modifier = Modifier.size(48.dp)
                            ) {
                                Icon(
                                    imageVector = if (isExpanded) Icons.Default.ExpandLess else Icons.Default.ExpandMore,
                                    contentDescription = "Expand chapters"
                                )
                            }
                            IconButton(
                                onClick = { editingSubject = subject },
                                modifier = Modifier.size(48.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Edit,
                                    contentDescription = "Edit subject",
                                    tint = PrimaryBlue
                                )
                            }
                            IconButton(
                                onClick = { deletingSubject = subject },
                                modifier = Modifier.size(48.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.DeleteOutline,
                                    contentDescription = "Delete subject",
                                    tint = WrongRed
                                )
                            }
                        }

                        if (isExpanded) {
                            HorizontalDivider(color = BorderOutline)
                            if (chapters.isEmpty()) {
                                Text(
                                    text = strings.noChaptersYet,
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                                    modifier = Modifier.padding(vertical = 4.dp)
                                )
                            } else {
                                chapters.forEach { chapter ->
                                    Row(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .padding(vertical = 4.dp),
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Column(modifier = Modifier.weight(1f)) {
                                            Text(
                                                text = chapter.name,
                                                style = MaterialTheme.typography.bodyMedium,
                                                fontWeight = FontWeight.SemiBold
                                            )
                                            Text(
                                                text = strings.mcqsCount(chapter.mcqCount),
                                                style = MaterialTheme.typography.bodySmall,
                                                color = PrimaryBlue
                                            )
                                        }
                                        IconButton(
                                            onClick = { onDeleteChapter(chapter.id) },
                                            modifier = Modifier.size(48.dp)
                                        ) {
                                            Icon(
                                                imageVector = Icons.Default.DeleteOutline,
                                                contentDescription = "Delete chapter",
                                                tint = WrongRed
                                            )
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    if (showAddDialog) {
        AddOrEditSubjectDialog(
            strings = strings,
            onDismiss = { showAddDialog = false },
            onConfirm = { name, emoji ->
                onAddSubject(name, emoji)
                showAddDialog = false
            }
        )
    }

    editingSubject?.let { subj ->
        AddOrEditSubjectDialog(
            strings = strings,
            initialName = subj.name,
            initialEmoji = subj.iconEmoji,
            isEdit = true,
            onDismiss = { editingSubject = null },
            onConfirm = { name, emoji ->
                onUpdateSubject(subj.id, name, emoji)
                editingSubject = null
            }
        )
    }

    deletingSubject?.let { subj ->
        AlertDialog(
            onDismissRequest = { deletingSubject = null },
            containerColor = MaterialTheme.colorScheme.background,
            shape = RoundedCornerShape(16.dp),
            title = { Text(strings.deleteSubjectConfirmTitle) },
            text = { Text(strings.deleteSubjectConfirmBody(subj.name)) },
            confirmButton = {
                Button(
                    onClick = {
                        onDeleteSubject(subj.id)
                        deletingSubject = null
                    },
                    shape = RoundedCornerShape(12.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = WrongRed),
                    modifier = Modifier.defaultMinSize(minHeight = 48.dp)
                ) {
                    Text(strings.delete)
                }
            },
            dismissButton = {
                TextButton(
                    onClick = { deletingSubject = null },
                    modifier = Modifier.defaultMinSize(minHeight = 48.dp)
                ) {
                    Text(strings.cancel)
                }
            }
        )
    }
}

@Composable
fun AboutScreen(
    strings: LocalizedStrings,
    modifier: Modifier = Modifier
) {
    Box(
        modifier = modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background),
        contentAlignment = Alignment.TopCenter
    ) {
        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            item(key = "about_card") {
                ElevatedBrandCard(
                    containerColor = MaterialTheme.colorScheme.surface,
                    border = BorderStroke(1.dp, BorderOutline)
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(20.dp),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        Surface(
                            shape = RoundedCornerShape(16.dp),
                            color = PrimaryBlueLight,
                            modifier = Modifier.size(68.dp)
                        ) {
                            Box(contentAlignment = Alignment.Center) {
                                Icon(
                                    imageVector = Icons.Default.School,
                                    contentDescription = strings.appName,
                                    tint = PrimaryBlue,
                                    modifier = Modifier.size(36.dp)
                                )
                            }
                        }
                        Text(
                            text = strings.appName,
                            style = MaterialTheme.typography.headlineMedium,
                            fontWeight = FontWeight.Bold,
                            color = PrimaryBlue
                        )
                        Text(
                            text = "Version 1.0 • Class 10 SSC (Bangladesh)",
                            style = MaterialTheme.typography.labelMedium,
                            color = MaterialTheme.colorScheme.secondary
                        )
                        Spacer(Modifier.height(4.dp))
                        Text(
                            text = strings.aboutDescription,
                            style = MaterialTheme.typography.bodyLarge,
                            color = MaterialTheme.colorScheme.onBackground
                        )
                    }
                }
            }
        }
    }
}

@Preview(
    showBackground = true,
    showSystemUi = true,
    device = "spec:width=360dp,height=800dp,dpi=420",
    uiMode = Configuration.UI_MODE_NIGHT_NO
)
@Composable
private fun ManageSubjectsScreenPreview() {
    MCQMasterTheme {
        ManageSubjectsScreen(
            subjects = listOf(
                SubjectWithStats(1L, "Physics", "⚛️", 2, 40),
                SubjectWithStats(2L, "Biology", "🧬", 1, 20)
            ),
            allChapters = listOf(
                ChapterWithCount(1L, 1L, "Chapter 1: Physical Quantities", 1730000000000L, 20, 20)
            ),
            strings = AppStrings.get(AppLanguage.ENGLISH),
            onAddSubject = { _, _ -> },
            onUpdateSubject = { _, _, _ -> },
            onDeleteSubject = {},
            onDeleteChapter = {}
        )
    }
}

@Preview(
    showBackground = true,
    showSystemUi = true,
    device = "spec:width=360dp,height=800dp,dpi=420",
    uiMode = Configuration.UI_MODE_NIGHT_NO
)
@Composable
private fun AboutScreenPreview() {
    MCQMasterTheme {
        AboutScreen(strings = AppStrings.get(AppLanguage.ENGLISH))
    }
}
