package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val PrimaryBlue = Color(0xFF1565C0)
val PrimaryBlueDark = Color(0xFF0D47A1)
val PrimaryBlueLight = Color(0xFFE3F2FD)
val SecondaryTeal = Color(0xFF0097A7)
val SecondaryTealLight = Color(0xFFE0F7FA)

val CorrectGreen = Color(0xFF2E7D32)
val CorrectGreenBg = Color(0xFFE8F5E9)
val WrongRed = Color(0xFFC62828)
val WrongRedBg = Color(0xFFFFEBEE)

val WarningOrange = Color(0xFFEF6C00)
val WarningOrangeBg = Color(0xFFFFF3E0)

val SurfaceLight = Color(0xFFF8F9FA)
val BackgroundWhite = Color(0xFFFFFFFF)
val TextPrimary = Color(0xFF1A1A2E)
val TextSecondary = Color(0xFF5A607F)
val BorderOutline = Color(0xFFDCE3EC)
