package com.example.ui.screens

import android.content.res.Configuration
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.GridItemSpan
import androidx.compose.foundation.lazy.grid.LazyGridState
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.grid.rememberLazyGridState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Key
import androidx.compose.material.icons.filled.LibraryBooks
import androidx.compose.material.icons.filled.Quiz
import androidx.compose.material.icons.filled.Today
import androidx.compose.material3.ExtendedFloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.data.local.ApiKeyStatus
import com.example.data.local.AppLanguage
import com.example.data.local.SubjectWithStats
import com.example.ui.HomeUiData
import com.example.ui.UiState
import com.example.ui.components.AddOrEditSubjectDialog
import com.example.ui.components.ElevatedBrandCard
import com.example.ui.components.PrimaryActionButton
import com.example.ui.components.ShimmerBox
import com.example.ui.theme.MCQMasterTheme
import com.example.ui.theme.PrimaryBlue
import com.example.ui.theme.PrimaryBlueDark
import com.example.ui.theme.PrimaryBlueLight
import com.example.ui.theme.SecondaryTeal
import com.example.ui.theme.SecondaryTealLight
import com.example.ui.theme.WarningOrange
import com.example.ui.theme.WarningOrangeBg
import com.example.ui.theme.WrongRed
import com.example.util.AppStrings
import com.example.util.LocalizedStrings

@Composable
fun HomeScreen(
    homeUiState: UiState<HomeUiData>,
    gridState: LazyGridState,
    apiStatus: ApiKeyStatus,
    strings: LocalizedStrings,
    onAddSubject: (name: String, emoji: String) -> Unit,
    onSubjectClick: (Long) -> Unit,
    onOpenImport: () -> Unit,
    onOpenSettings: () -> Unit,
    modifier: Modifier = Modifier
) {
    var showAddDialog by remember { mutableStateOf(false) }

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background),
        contentAlignment = Alignment.TopCenter
    ) {
        when (homeUiState) {
            is UiState.Loading -> {
                HomeShimmerSkeleton(modifier = Modifier.fillMaxWidth())
            }

            is UiState.Error -> {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(24.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = homeUiState.message,
                        color = WrongRed,
                        style = MaterialTheme.typography.bodyLarge
                    )
                }
            }

            is UiState.Success -> {
                val data = homeUiState.data
                LazyVerticalGrid(
                    columns = GridCells.Fixed(2),
                    state = gridState,
                    modifier = Modifier.fillMaxSize(),
                    contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 12.dp, bottom = 96.dp),
                    horizontalArrangement = Arrangement.spacedBy(12.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    item(key = "welcome_header", span = { GridItemSpan(2) }) {
                        WelcomeHeaderCard(strings = strings, onOpenImport = onOpenImport)
                    }

                    item(key = "summary_row", span = { GridItemSpan(2) }) {
                        SummaryMetricsRow(
                            totalMcqs = data.totalMcqs,
                            subjectCount = data.subjects.size,
                            todaySessions = data.todaySessions,
                            strings = strings
                        )
                    }

                    if (apiStatus == ApiKeyStatus.NOT_SET) {
                        item(key = "api_missing_banner", span = { GridItemSpan(2) }) {
                            ApiKeyNoticeBanner(strings = strings, onOpenSettings = onOpenSettings)
                        }
                    }

                    if (data.subjects.isEmpty()) {
                        item(key = "empty_subjects", span = { GridItemSpan(2) }) {
                            EmptySubjectsCard(
                                strings = strings,
                                onAddSubjectClick = { showAddDialog = true }
                            )
                        }
                    } else {
                        item(key = "subjects_heading", span = { GridItemSpan(2) }) {
                            Text(
                                text = strings.yourSubjects,
                                style = MaterialTheme.typography.titleLarge,
                                color = MaterialTheme.colorScheme.onBackground,
                                modifier = Modifier.padding(top = 4.dp)
                            )
                        }

                        items(data.subjects, key = { it.id }) { subject ->
                            SubjectGridCard(
                                subject = subject,
                                strings = strings,
                                onClick = { onSubjectClick(subject.id) }
                            )
                        }
                    }
                }
            }
        }

        ExtendedFloatingActionButton(
            onClick = { showAddDialog = true },
            icon = { Icon(Icons.Default.Add, contentDescription = strings.addSubject) },
            text = { Text(strings.addSubject, style = MaterialTheme.typography.labelLarge) },
            containerColor = PrimaryBlue,
            contentColor = Color.White,
            shape = RoundedCornerShape(16.dp),
            modifier = Modifier
                .align(Alignment.BottomEnd)
                .padding(16.dp)
                .testTag("add_subject_fab")
        )
    }

    if (showAddDialog) {
        AddOrEditSubjectDialog(
            strings = strings,
            onDismiss = { showAddDialog = false },
            onConfirm = { name, emoji ->
                onAddSubject(name, emoji)
                showAddDialog = false
            }
        )
    }
}

@Composable
private fun HomeShimmerSkeleton(modifier: Modifier = Modifier) {
    Column(
        modifier = modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        ShimmerBox(modifier = Modifier.fillMaxWidth(), height = 140.dp, cornerRadius = 16.dp)
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            repeat(3) {
                ShimmerBox(
                    modifier = Modifier.weight(1f),
                    height = 96.dp,
                    cornerRadius = 16.dp
                )
            }
        }
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            ShimmerBox(modifier = Modifier.weight(1f), height = 132.dp, cornerRadius = 16.dp)
            ShimmerBox(modifier = Modifier.weight(1f), height = 132.dp, cornerRadius = 16.dp)
        }
    }
}

@Composable
private fun SummaryMetricsRow(
    totalMcqs: Int,
    subjectCount: Int,
    todaySessions: Int,
    strings: LocalizedStrings
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        SummaryMetricCard(
            icon = Icons.Default.Quiz,
            value = totalMcqs.toString(),
            label = strings.totalMcqsSaved,
            accent = PrimaryBlue,
            bg = PrimaryBlueLight,
            modifier = Modifier.weight(1f)
        )
        SummaryMetricCard(
            icon = Icons.Default.LibraryBooks,
            value = subjectCount.toString(),
            label = strings.subjectsLabel,
            accent = SecondaryTeal,
            bg = SecondaryTealLight,
            modifier = Modifier.weight(1f)
        )
        SummaryMetricCard(
            icon = Icons.Default.Today,
            value = todaySessions.toString(),
            label = strings.todaysSessions,
            accent = Color(0xFF2E7D32),
            bg = Color(0xFFE8F5E9),
            modifier = Modifier.weight(1f)
        )
    }
}

@Composable
private fun ApiKeyNoticeBanner(
    strings: LocalizedStrings,
    onOpenSettings: () -> Unit
) {
    Surface(
        shape = RoundedCornerShape(16.dp),
        color = WarningOrangeBg,
        modifier = Modifier.fillMaxWidth()
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 14.dp, vertical = 10.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(
                imageVector = Icons.Default.Key,
                contentDescription = null,
                tint = WarningOrange
            )
            Spacer(Modifier.width(10.dp))
            Text(
                text = strings.apiBannerMissing,
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onBackground,
                modifier = Modifier.weight(1f)
            )
            TextButton(
                onClick = onOpenSettings,
                modifier = Modifier.testTag("home_open_settings_button")
            ) {
                Text(strings.openSettings, fontWeight = FontWeight.Bold)
            }
        }
    }
}

@Composable
private fun WelcomeHeaderCard(
    strings: LocalizedStrings,
    onOpenImport: () -> Unit
) {
    Surface(
        shape = RoundedCornerShape(16.dp),
        shadowElevation = 2.dp,
        modifier = Modifier.fillMaxWidth()
    ) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .background(
                    Brush.linearGradient(
                        colors = listOf(PrimaryBlue, PrimaryBlueDark, SecondaryTeal)
                    )
                )
                .padding(20.dp)
        ) {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text(
                    text = strings.welcomeHeader,
                    style = MaterialTheme.typography.headlineMedium,
                    color = Color.White,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    text = strings.welcomeSubheader,
                    style = MaterialTheme.typography.bodyMedium,
                    color = Color.White.copy(alpha = 0.88f)
                )
                Spacer(Modifier.height(4.dp))
                Surface(
                    onClick = onOpenImport,
                    shape = RoundedCornerShape(12.dp),
                    color = Color.White.copy(alpha = 0.18f),
                    modifier = Modifier.testTag("home_quick_import_button")
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 14.dp, vertical = 10.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = Icons.Default.AutoAwesome,
                            contentDescription = null,
                            tint = Color.White,
                            modifier = Modifier.size(18.dp)
                        )
                        Spacer(Modifier.width(8.dp))
                        Text(
                            text = strings.menuImportMcq,
                            style = MaterialTheme.typography.labelLarge,
                            color = Color.White
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun SummaryMetricCard(
    icon: ImageVector,
    value: String,
    label: String,
    accent: Color,
    bg: Color,
    modifier: Modifier = Modifier
) {
    ElevatedBrandCard(modifier = modifier) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            Box(
                modifier = Modifier
                    .size(36.dp)
                    .clip(CircleShape)
                    .background(bg),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = icon,
                    contentDescription = label,
                    tint = accent,
                    modifier = Modifier.size(20.dp)
                )
            }
            Text(
                text = value,
                style = MaterialTheme.typography.headlineSmall,
                color = MaterialTheme.colorScheme.onBackground,
                fontWeight = FontWeight.Bold
            )
            Text(
                text = label,
                style = MaterialTheme.typography.labelMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
        }
    }
}

@Composable
private fun SubjectGridCard(
    subject: SubjectWithStats,
    strings: LocalizedStrings,
    onClick: () -> Unit
) {
    ElevatedBrandCard(
        onClick = onClick,
        modifier = Modifier
            .fillMaxWidth()
            .testTag("subject_card_${subject.id}")
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Box(
                modifier = Modifier
                    .size(48.dp)
                    .clip(RoundedCornerShape(12.dp))
                    .background(PrimaryBlueLight),
                contentAlignment = Alignment.Center
            ) {
                Text(text = subject.iconEmoji, fontSize = 24.sp)
            }

            Text(
                text = subject.name,
                style = MaterialTheme.typography.titleLarge,
                color = MaterialTheme.colorScheme.onBackground,
                maxLines = 2,
                overflow = TextOverflow.Ellipsis
            )

            Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
                Text(
                    text = strings.chaptersCount(subject.chapterCount),
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Text(
                    text = strings.mcqsCount(subject.mcqCount),
                    style = MaterialTheme.typography.labelMedium,
                    color = PrimaryBlue,
                    fontWeight = FontWeight.Bold
                )
            }
        }
    }
}

@Composable
private fun EmptySubjectsCard(
    strings: LocalizedStrings,
    onAddSubjectClick: () -> Unit
) {
    ElevatedBrandCard(
        containerColor = MaterialTheme.colorScheme.background,
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Image(
                painter = painterResource(id = R.drawable.ic_empty_subjects),
                contentDescription = strings.emptyHomeTitle,
                contentScale = ContentScale.Fit,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(160.dp)
            )
            Text(
                text = strings.emptyHomeTitle,
                style = MaterialTheme.typography.headlineSmall,
                textAlign = TextAlign.Center,
                color = MaterialTheme.colorScheme.onBackground
            )
            Text(
                text = strings.emptyHomeSubtitle,
                style = MaterialTheme.typography.bodyMedium,
                textAlign = TextAlign.Center,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            Spacer(Modifier.height(4.dp))
            PrimaryActionButton(
                text = strings.addSubject,
                onClick = onAddSubjectClick,
                icon = Icons.Default.Add,
                modifier = Modifier.testTag("empty_state_add_subject_button")
            )
        }
    }
}

@Preview(
    showBackground = true,
    showSystemUi = true,
    device = "spec:width=360dp,height=800dp,dpi=420",
    uiMode = Configuration.UI_MODE_NIGHT_NO
)
@Composable
private fun HomeScreenPreview() {
    MCQMasterTheme {
        HomeScreen(
            homeUiState = UiState.Success(
                HomeUiData(
                    subjects = listOf(
                        SubjectWithStats(1L, "Physics", "⚛️", 3, 45),
                        SubjectWithStats(2L, "Chemistry", "🧪", 2, 30)
                    ),
                    totalMcqs = 75,
                    todaySessions = 2
                )
            ),
            gridState = rememberLazyGridState(),
            apiStatus = ApiKeyStatus.CONNECTED,
            strings = AppStrings.get(AppLanguage.ENGLISH),
            onAddSubject = { _, _ -> },
            onSubjectClick = {},
            onOpenImport = {},
            onOpenSettings = {}
        )
    }
}
