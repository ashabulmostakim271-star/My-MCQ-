package com.example.ui.screens

import android.content.res.Configuration
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyListState
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Assessment
import androidx.compose.material.icons.filled.Timer
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.local.AppLanguage
import com.example.data.local.QuizSessionWithMeta
import com.example.data.local.SubjectWithStats
import com.example.ui.UiState
import com.example.ui.components.ElevatedBrandCard
import com.example.ui.components.ListShimmerPlaceholder
import com.example.ui.theme.CorrectGreen
import com.example.ui.theme.CorrectGreenBg
import com.example.ui.theme.MCQMasterTheme
import com.example.ui.theme.PrimaryBlue
import com.example.ui.theme.PrimaryBlueLight
import com.example.ui.theme.WarningOrange
import com.example.ui.theme.WarningOrangeBg
import com.example.ui.theme.WrongRed
import com.example.ui.theme.WrongRedBg
import com.example.util.AppStrings
import com.example.util.LocalizedStrings
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun HistoryScreen(
    historyUiState: UiState<List<QuizSessionWithMeta>>,
    subjects: List<SubjectWithStats>,
    selectedSubjectFilter: Long?,
    listState: LazyListState,
    strings: LocalizedStrings,
    onSelectFilter: (Long?) -> Unit,
    modifier: Modifier = Modifier
) {
    val dateFormatter = remember { SimpleDateFormat("dd MMM yyyy • hh:mm a", Locale.getDefault()) }

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background),
        contentAlignment = Alignment.TopCenter
    ) {
        when (historyUiState) {
            is UiState.Loading -> {
                ListShimmerPlaceholder(modifier = Modifier.fillMaxWidth())
            }

            is UiState.Error -> {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(24.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = historyUiState.message,
                        color = WrongRed,
                        style = MaterialTheme.typography.bodyLarge
                    )
                }
            }

            is UiState.Success -> {
                val sessions = historyUiState.data
                val filteredSessions by remember(sessions, selectedSubjectFilter) {
                    derivedStateOf {
                        if (selectedSubjectFilter == null) sessions
                        else sessions.filter { it.subjectId == selectedSubjectFilter }
                    }
                }
                val avgPercentage by remember(filteredSessions) {
                    derivedStateOf {
                        if (filteredSessions.isEmpty()) 0
                        else {
                            val sumPct = filteredSessions.sumOf { session ->
                                if (session.total > 0) (session.score * 100) / session.total else 0
                            }
                            sumPct / filteredSessions.size
                        }
                    }
                }

                LazyColumn(
                    state = listState,
                    modifier = Modifier.fillMaxSize(),
                    contentPadding = PaddingValues(16.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    item(key = "overall_stats_card") {
                        HistoryOverallStatsCard(
                            totalSessions = filteredSessions.size,
                            avgPercentage = avgPercentage,
                            strings = strings
                        )
                    }

                    if (subjects.isNotEmpty()) {
                        item(key = "history_subject_filters") {
                            FlowRow(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(8.dp),
                                verticalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                FilterChip(
                                    selected = selectedSubjectFilter == null,
                                    onClick = { onSelectFilter(null) },
                                    label = { Text(strings.filterAll) },
                                    colors = FilterChipDefaults.filterChipColors(
                                        selectedContainerColor = PrimaryBlueLight,
                                        selectedLabelColor = PrimaryBlue
                                    ),
                                    modifier = Modifier
                                        .heightIn(min = 48.dp)
                                        .testTag("history_filter_all")
                                )
                                subjects.forEach { subject ->
                                    FilterChip(
                                        selected = selectedSubjectFilter == subject.id,
                                        onClick = { onSelectFilter(subject.id) },
                                        label = { Text("${subject.iconEmoji} ${subject.name}") },
                                        colors = FilterChipDefaults.filterChipColors(
                                            selectedContainerColor = PrimaryBlueLight,
                                            selectedLabelColor = PrimaryBlue
                                        ),
                                        modifier = Modifier.heightIn(min = 48.dp)
                                    )
                                }
                            }
                        }
                    }

                    if (filteredSessions.isEmpty()) {
                        item(key = "history_empty_state") {
                            EmptyHistoryCard(strings = strings)
                        }
                    } else {
                        items(filteredSessions, key = { it.id }) { session ->
                            HistorySessionCard(
                                session = session,
                                formattedDate = remember(session.dateTaken) {
                                    dateFormatter.format(Date(session.dateTaken))
                                },
                                allChaptersLabel = strings.allChapters
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun HistoryOverallStatsCard(
    totalSessions: Int,
    avgPercentage: Int,
    strings: LocalizedStrings
) {
    ElevatedBrandCard(
        containerColor = PrimaryBlueLight,
        modifier = Modifier.fillMaxWidth()
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(18.dp),
            horizontalArrangement = Arrangement.SpaceEvenly
        ) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Text(
                    text = totalSessions.toString(),
                    style = MaterialTheme.typography.headlineMedium,
                    color = PrimaryBlue,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    text = strings.totalSessionsLabel,
                    style = MaterialTheme.typography.labelMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Text(
                    text = "$avgPercentage%",
                    style = MaterialTheme.typography.headlineMedium,
                    color = PrimaryBlue,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    text = strings.averageScoreLabel,
                    style = MaterialTheme.typography.labelMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }
    }
}

@Composable
private fun EmptyHistoryCard(strings: LocalizedStrings) {
    ElevatedBrandCard(containerColor = MaterialTheme.colorScheme.background) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(28.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Icon(
                imageVector = Icons.Default.Assessment,
                contentDescription = null,
                tint = PrimaryBlue.copy(alpha = 0.6f),
                modifier = Modifier.size(52.dp)
            )
            Text(
                text = strings.emptyHistoryTitle,
                style = MaterialTheme.typography.titleLarge,
                textAlign = TextAlign.Center
            )
            Text(
                text = strings.emptyHistorySubtitle,
                style = MaterialTheme.typography.bodyMedium,
                textAlign = TextAlign.Center,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
    }
}

@Composable
private fun HistorySessionCard(
    session: QuizSessionWithMeta,
    formattedDate: String,
    allChaptersLabel: String
) {
    val pct = if (session.total > 0) (session.score * 100) / session.total else 0
    val badgeColor: Color
    val badgeBg: Color
    when {
        pct >= 60 -> {
            badgeColor = CorrectGreen
            badgeBg = CorrectGreenBg
        }
        pct >= 40 -> {
            badgeColor = WarningOrange
            badgeBg = WarningOrangeBg
        }
        else -> {
            badgeColor = WrongRed
            badgeBg = WrongRedBg
        }
    }

    ElevatedBrandCard(
        modifier = Modifier
            .fillMaxWidth()
            .testTag("history_session_${session.id}")
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(46.dp)
                    .background(PrimaryBlueLight, RoundedCornerShape(12.dp)),
                contentAlignment = Alignment.Center
            ) {
                Text(text = session.subjectEmoji, fontSize = 22.sp)
            }
            Spacer(Modifier.width(12.dp))
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = session.subjectName.ifBlank { "Subject" },
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    text = session.chapterName ?: allChaptersLabel,
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.secondary
                )
                Spacer(Modifier.height(2.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        text = formattedDate,
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Spacer(Modifier.width(8.dp))
                    Icon(
                        imageVector = Icons.Default.Timer,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.size(12.dp)
                    )
                    Spacer(Modifier.width(3.dp))
                    Text(
                        text = "${session.durationSeconds}s",
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
            Surface(
                shape = RoundedCornerShape(12.dp),
                color = badgeBg
            ) {
                Column(
                    modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text(
                        text = "$pct%",
                        style = MaterialTheme.typography.titleMedium,
                        color = badgeColor,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = "${session.score}/${session.total}",
                        style = MaterialTheme.typography.labelSmall,
                        color = badgeColor
                    )
                }
            }
        }
    }
}

@Preview(
    showBackground = true,
    showSystemUi = true,
    device = "spec:width=360dp,height=800dp,dpi=420",
    uiMode = Configuration.UI_MODE_NIGHT_NO
)
@Composable
private fun HistoryScreenPreview() {
    MCQMasterTheme {
        HistoryScreen(
            historyUiState = UiState.Success(
                listOf(
                    QuizSessionWithMeta(
                        id = 1L,
                        subjectId = 1L,
                        chapterId = 1L,
                        score = 18,
                        total = 20,
                        wrongCount = 2,
                        skippedCount = 0,
                        dateTaken = 1730000000000L,
                        durationSeconds = 245,
                        subjectName = "Physics",
                        subjectEmoji = "⚛️",
                        chapterName = "Motion & Force"
                    )
                )
            ),
            subjects = listOf(
                SubjectWithStats(1L, "Physics", "⚛️", 3, 45),
                SubjectWithStats(2L, "Chemistry", "🧪", 2, 30)
            ),
            selectedSubjectFilter = null,
            listState = rememberLazyListState(),
            strings = AppStrings.get(AppLanguage.ENGLISH),
            onSelectFilter = {}
        )
    }
}
