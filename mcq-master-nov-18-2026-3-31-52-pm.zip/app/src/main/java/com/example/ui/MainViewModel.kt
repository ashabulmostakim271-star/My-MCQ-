package com.example.ui

import android.net.Uri
import androidx.compose.runtime.Immutable
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.example.data.local.ApiKeyStatus
import com.example.data.local.AppLanguage
import com.example.data.local.AppPreferences
import com.example.data.local.ChapterWithCount
import com.example.data.local.ExplanationMode
import com.example.data.local.InputHistoryItem
import com.example.data.local.McqEntity
import com.example.data.local.QuizSessionWithMeta
import com.example.data.local.SubjectEntity
import com.example.data.local.SubjectWithStats
import com.example.data.remote.ExtractedMcqDraft
import com.example.data.remote.PickedDocumentInfo
import com.example.data.remote.SourceFileType
import com.example.data.repository.McqRepository
import com.example.util.SoundEffectHelper
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

@Immutable
sealed interface UiState<out T> {
    data object Loading : UiState<Nothing>
    @Immutable
    data class Success<T>(val data: T) : UiState<T>
    @Immutable
    data class Error(val message: String) : UiState<Nothing>
}

@Immutable
data class HomeUiData(
    val subjects: List<SubjectWithStats>,
    val totalMcqs: Int,
    val todaySessions: Int
)

enum class QuestionCountOption(val limit: Int?) {
    TEN(10),
    TWENTY(20),
    THIRTY(30),
    FIFTY(50),
    ALL(null)
}

enum class QuestionOrder {
    RANDOM,
    SEQUENTIAL
}

@Immutable
data class ImportUiState(
    val selectedSubjectId: Long? = null,
    val chapterName: String = "",
    val pickedDocument: PickedDocumentInfo? = null,
    val isExtracting: Boolean = false,
    val extractionProgressText: String = "",
    val extractedDrafts: List<ExtractedMcqDraft> = emptyList(),
    val hasAttemptedExtraction: Boolean = false,
    val errorMessage: String? = null,
    val isSaving: Boolean = false
)

@Immutable
data class QuizSetupState(
    val selectedSubjectId: Long? = null,
    val selectedChapterId: Long? = null, // null means "All Chapters"
    val questionCountOption: QuestionCountOption = QuestionCountOption.TWENTY,
    val order: QuestionOrder = QuestionOrder.RANDOM,
    val totalInSelection: Int = 0,
    val validInSelection: Int = 0,
    val unknownInSelection: Int = 0
)

@Immutable
data class ActiveQuizState(
    val subjectId: Long = 0,
    val subjectName: String = "",
    val subjectEmoji: String = "📘",
    val chapterId: Long? = null,
    val chapterName: String? = null,
    val questions: List<McqEntity> = emptyList(),
    val currentIndex: Int = 0,
    val selectedOption: String? = null,
    val isAnswerRevealed: Boolean = false,
    val correctCount: Int = 0,
    val wrongCount: Int = 0,
    val autoSkippedUnknownCount: Int = 0,
    val userSkippedCount: Int = 0,
    val wrongMcqs: List<McqEntity> = emptyList(),
    val startTimeMillis: Long = System.currentTimeMillis(),
    val isRetryMode: Boolean = false
) {
    val currentQuestion: McqEntity? get() = questions.getOrNull(currentIndex)
    val nextQuestion: McqEntity? get() = questions.getOrNull(currentIndex + 1)
    val totalPlayable: Int get() = questions.size
    val totalSkipped: Int get() = autoSkippedUnknownCount + userSkippedCount
}

@Immutable
data class QuizResultState(
    val subjectId: Long = 0,
    val subjectName: String = "",
    val chapterName: String? = null,
    val correctCount: Int = 0,
    val wrongCount: Int = 0,
    val skippedCount: Int = 0,
    val totalAnsweredOrPlayable: Int = 0,
    val durationSeconds: Int = 0,
    val wrongMcqs: List<McqEntity> = emptyList()
) {
    val percentage: Int
        get() = if (totalAnsweredOrPlayable <= 0) 0
        else ((correctCount.toFloat() / totalAnsweredOrPlayable.toFloat()) * 100f).toInt()
}

@Immutable
data class SettingsTestState(
    val isTesting: Boolean = false,
    val testMessage: String? = null,
    val isError: Boolean = false
)

class MainViewModel(
    private val repository: McqRepository,
    private val soundEffectHelper: SoundEffectHelper
) : ViewModel() {

    // Cached streams across tabs so navigating back never re-queries from scratch
    val subjectsWithStats: StateFlow<List<SubjectWithStats>> = repository.subjectsWithStats
        .stateIn(viewModelScope, SharingStarted.Lazily, emptyList())

    val allChapters: StateFlow<List<ChapterWithCount>> = repository.allChapters
        .stateIn(viewModelScope, SharingStarted.Lazily, emptyList())

    val homeUiState: StateFlow<UiState<HomeUiData>> = combine(
        repository.subjectsWithStats,
        repository.totalMcqCount,
        repository.observeTodaySessionsCount()
    ) { subjects, totalMcqs, todaySessions ->
        UiState.Success(
            HomeUiData(
                subjects = subjects,
                totalMcqs = totalMcqs,
                todaySessions = todaySessions
            )
        ) as UiState<HomeUiData>
    }.catch { err ->
        emit(UiState.Error(err.message ?: "Failed to load subjects."))
    }.stateIn(viewModelScope, SharingStarted.Eagerly, UiState.Loading)

    val historyUiState: StateFlow<UiState<List<QuizSessionWithMeta>>> = repository.quizSessions
        .map<List<QuizSessionWithMeta>, UiState<List<QuizSessionWithMeta>>> { UiState.Success(it) }
        .catch { err -> emit(UiState.Error(err.message ?: "Failed to load history.")) }
        .stateIn(viewModelScope, SharingStarted.Lazily, UiState.Loading)

    val inputHistoryUiState: StateFlow<UiState<List<InputHistoryItem>>> = repository.inputHistory
        .map<List<InputHistoryItem>, UiState<List<InputHistoryItem>>> { UiState.Success(it) }
        .catch { err -> emit(UiState.Error(err.message ?: "Failed to load input history.")) }
        .stateIn(viewModelScope, SharingStarted.Lazily, UiState.Loading)

    val preferences: StateFlow<AppPreferences> = repository.preferencesFlow
        .stateIn(viewModelScope, SharingStarted.Eagerly, AppPreferences())

    // Used by Android 12+ SplashScreen API: dismisses immediately once real initial data is ready
    val isInitialDataReady: StateFlow<Boolean> = homeUiState
        .map { it !is UiState.Loading }
        .stateIn(viewModelScope, SharingStarted.Eagerly, false)

    val apiKey: StateFlow<String> = repository.apiKeyState
    val apiStatus: StateFlow<ApiKeyStatus> = repository.apiConnectionStatus

    private val _importState = MutableStateFlow(ImportUiState())
    val importState: StateFlow<ImportUiState> = _importState.asStateFlow()

    private val _quizSetupState = MutableStateFlow(QuizSetupState())
    val quizSetupState: StateFlow<QuizSetupState> = _quizSetupState.asStateFlow()

    private val _activeQuizState = MutableStateFlow<ActiveQuizState?>(null)
    val activeQuizState: StateFlow<ActiveQuizState?> = _activeQuizState.asStateFlow()

    private val _quizResultState = MutableStateFlow<QuizResultState?>(null)
    val quizResultState: StateFlow<QuizResultState?> = _quizResultState.asStateFlow()

    private val _settingsTestState = MutableStateFlow(SettingsTestState())
    val settingsTestState: StateFlow<SettingsTestState> = _settingsTestState.asStateFlow()

    private val _historySubjectFilter = MutableStateFlow<Long?>(null)
    val historySubjectFilter: StateFlow<Long?> = _historySubjectFilter.asStateFlow()

    private val _snackbarMessage = MutableStateFlow<String?>(null)
    val snackbarMessage: StateFlow<String?> = _snackbarMessage.asStateFlow()

    fun consumeSnackbar() {
        _snackbarMessage.value = null
    }

    fun showSnackbar(msg: String) {
        _snackbarMessage.value = msg
    }

    // Subject & Chapter CRUD
    fun addSubject(name: String, emoji: String, onCreated: ((Long) -> Unit)? = null) {
        if (name.isBlank()) return
        viewModelScope.launch {
            val id = repository.addSubject(name, emoji)
            onCreated?.invoke(id)
        }
    }

    fun updateSubject(id: Long, name: String, emoji: String) {
        if (name.isBlank()) return
        viewModelScope.launch {
            repository.updateSubject(SubjectEntity(id = id, name = name.trim(), iconEmoji = emoji))
        }
    }

    fun deleteSubject(subjectId: Long) {
        viewModelScope.launch {
            repository.deleteSubject(subjectId)
            if (_quizSetupState.value.selectedSubjectId == subjectId) {
                _quizSetupState.update { it.copy(selectedSubjectId = null, selectedChapterId = null) }
            }
            if (_importState.value.selectedSubjectId == subjectId) {
                _importState.update { it.copy(selectedSubjectId = null) }
            }
        }
    }

    fun deleteChapter(chapterId: Long) {
        viewModelScope.launch {
            repository.deleteChapter(chapterId)
            if (_quizSetupState.value.selectedChapterId == chapterId) {
                _quizSetupState.update { it.copy(selectedChapterId = null) }
                refreshQuizSelectionCounts()
            }
        }
    }

    // Selective History Deletion
    fun deleteSelectedInputHistory(chapterIds: List<Long>, onDeleted: (Int) -> Unit) {
        if (chapterIds.isEmpty()) return
        viewModelScope.launch {
            val deletedCount = repository.deleteInputHistoryChapters(chapterIds)
            if (_quizSetupState.value.selectedChapterId in chapterIds) {
                _quizSetupState.update { it.copy(selectedChapterId = null) }
            }
            refreshQuizSelectionCounts()
            onDeleted(deletedCount)
        }
    }

    fun deleteSelectedOutputHistory(sessionIds: List<Long>, onDeleted: (Int) -> Unit) {
        if (sessionIds.isEmpty()) return
        viewModelScope.launch {
            val deletedCount = repository.deleteOutputHistorySessions(sessionIds)
            onDeleted(deletedCount)
        }
    }

    // Import MCQ flow
    fun selectImportSubject(subjectId: Long) {
        _importState.update { it.copy(selectedSubjectId = subjectId, errorMessage = null) }
    }

    fun updateImportChapterName(name: String) {
        _importState.update { it.copy(chapterName = name, errorMessage = null) }
    }

    fun onSourceFilePicked(uri: Uri, type: SourceFileType) {
        viewModelScope.launch {
            val doc = repository.inspectPickedFile(uri, type)
            _importState.update {
                it.copy(
                    pickedDocument = doc,
                    extractedDrafts = emptyList(),
                    hasAttemptedExtraction = false,
                    errorMessage = null
                )
            }
        }
    }

    fun extractMcqsWithGemini(noMcqsMsg: String) {
        val state = _importState.value
        val doc = state.pickedDocument ?: return
        if (state.isExtracting) return

        viewModelScope.launch {
            _importState.update {
                it.copy(
                    isExtracting = true,
                    extractionProgressText = "",
                    errorMessage = null,
                    hasAttemptedExtraction = true
                )
            }
            val result = repository.extractMcqsFromDocument(doc) { progress ->
                _importState.update { it.copy(extractionProgressText = progress) }
            }
            result.fold(
                onSuccess = { drafts ->
                    _importState.update {
                        it.copy(
                            isExtracting = false,
                            extractedDrafts = drafts,
                            errorMessage = if (drafts.isEmpty()) noMcqsMsg else null
                        )
                    }
                },
                onFailure = { error ->
                    _importState.update {
                        it.copy(
                            isExtracting = false,
                            errorMessage = error.message ?: "Extraction failed."
                        )
                    }
                }
            )
        }
    }

    fun updateDraftMcq(updated: ExtractedMcqDraft) {
        _importState.update { state ->
            state.copy(
                extractedDrafts = state.extractedDrafts.map {
                    if (it.localId == updated.localId) updated else it
                }
            )
        }
    }

    fun deleteDraftMcq(localId: String) {
        _importState.update { state ->
            state.copy(
                extractedDrafts = state.extractedDrafts.filterNot { it.localId == localId }
            )
        }
    }

    fun saveExtractedMcqs(onSuccess: (Int) -> Unit) {
        val state = _importState.value
        val subjectId = state.selectedSubjectId ?: return
        val chapterName = state.chapterName.trim()
        if (chapterName.isEmpty() || state.extractedDrafts.isEmpty()) return

        viewModelScope.launch {
            _importState.update { it.copy(isSaving = true) }
            val count = repository.saveExtractedMcqs(subjectId, chapterName, state.extractedDrafts)
            _importState.value = ImportUiState(selectedSubjectId = subjectId)
            refreshQuizSelectionCounts()
            onSuccess(count)
        }
    }

    // Practice Setup
    fun selectPracticeSubject(subjectId: Long) {
        _quizSetupState.update {
            it.copy(selectedSubjectId = subjectId, selectedChapterId = null)
        }
        refreshQuizSelectionCounts()
    }

    fun selectPracticeChapter(chapterId: Long?) {
        _quizSetupState.update { it.copy(selectedChapterId = chapterId) }
        refreshQuizSelectionCounts()
    }

    fun selectQuestionCountOption(option: QuestionCountOption) {
        _quizSetupState.update { it.copy(questionCountOption = option) }
    }

    fun selectQuestionOrder(order: QuestionOrder) {
        _quizSetupState.update { it.copy(order = order) }
    }

    fun refreshQuizSelectionCounts() {
        val subjectId = _quizSetupState.value.selectedSubjectId ?: return
        val chapterId = _quizSetupState.value.selectedChapterId
        viewModelScope.launch {
            val all = repository.getMcqsForQuiz(subjectId, chapterId)
            val valid = all.count { it.correctAnswer in VALID_ANSWERS }
            val unknown = all.size - valid
            _quizSetupState.update {
                it.copy(
                    totalInSelection = all.size,
                    validInSelection = valid,
                    unknownInSelection = unknown
                )
            }
        }
    }

    fun startPracticeQuiz(onStarted: () -> Unit, onEmpty: () -> Unit) {
        val setup = _quizSetupState.value
        val subjectId = setup.selectedSubjectId ?: run {
            onEmpty()
            return
        }
        viewModelScope.launch {
            // Preload all quiz questions into memory on Dispatchers.IO before entering QuizScreen
            val allMcqs = repository.getMcqsForQuiz(subjectId, setup.selectedChapterId)
            val validMcqs = allMcqs.filter { it.correctAnswer in VALID_ANSWERS }
            val unknownCount = allMcqs.size - validMcqs.size

            if (validMcqs.isEmpty()) {
                onEmpty()
                return@launch
            }

            val ordered = when (setup.order) {
                QuestionOrder.RANDOM -> validMcqs.shuffled()
                QuestionOrder.SEQUENTIAL -> validMcqs
            }
            val limit = setup.questionCountOption.limit
            val selected = if (limit != null) ordered.take(limit) else ordered

            val subject = subjectsWithStats.value.find { it.id == subjectId }
            val chapter = setup.selectedChapterId?.let { cid ->
                allChapters.value.find { it.id == cid }
            }

            _activeQuizState.value = ActiveQuizState(
                subjectId = subjectId,
                subjectName = subject?.name.orEmpty(),
                subjectEmoji = subject?.iconEmoji ?: "📘",
                chapterId = setup.selectedChapterId,
                chapterName = chapter?.name,
                questions = selected,
                currentIndex = 0,
                autoSkippedUnknownCount = unknownCount,
                startTimeMillis = System.currentTimeMillis(),
                isRetryMode = false
            )
            _quizResultState.value = null
            onStarted()
        }
    }

    // Instant in-memory answer tap (< 16ms) with background audio + pre-warmed next question
    fun submitAnswer(option: String) {
        val quiz = _activeQuizState.value ?: return
        if (quiz.isAnswerRevealed) return
        val current = quiz.currentQuestion ?: return
        val isCorrect = current.correctAnswer.equals(option, ignoreCase = true)

        if (preferences.value.soundEffectsEnabled) {
            if (isCorrect) {
                soundEffectHelper.playCorrect(viewModelScope)
            } else {
                soundEffectHelper.playWrong(viewModelScope)
            }
        }

        _activeQuizState.value = quiz.copy(
            selectedOption = option,
            isAnswerRevealed = true,
            correctCount = quiz.correctCount + if (isCorrect) 1 else 0,
            wrongCount = quiz.wrongCount + if (!isCorrect) 1 else 0,
            wrongMcqs = if (isCorrect) quiz.wrongMcqs else quiz.wrongMcqs + current
        )

        // Pre-warm / validate next question in background while current answer is displayed
        quiz.nextQuestion?.let { next ->
            viewModelScope.launch(Dispatchers.Default) {
                next.question.length + next.optionA.length
            }
        }
    }

    fun skipCurrentQuestion(onQuizFinished: () -> Unit) {
        val quiz = _activeQuizState.value ?: return
        if (quiz.isAnswerRevealed) return
        val updated = quiz.copy(userSkippedCount = quiz.userSkippedCount + 1)
        advanceQuizOrFinish(updated, onQuizFinished)
    }

    fun moveToNextQuestion(onQuizFinished: () -> Unit) {
        val quiz = _activeQuizState.value ?: return
        advanceQuizOrFinish(quiz, onQuizFinished)
    }

    private fun advanceQuizOrFinish(quiz: ActiveQuizState, onQuizFinished: () -> Unit) {
        val nextIndex = quiz.currentIndex + 1
        if (nextIndex < quiz.questions.size) {
            _activeQuizState.value = quiz.copy(
                currentIndex = nextIndex,
                selectedOption = null,
                isAnswerRevealed = false
            )
        } else {
            val durationSeconds =
                ((System.currentTimeMillis() - quiz.startTimeMillis) / 1000L).toInt().coerceAtLeast(1)
            val resultState = QuizResultState(
                subjectId = quiz.subjectId,
                subjectName = quiz.subjectName,
                chapterName = quiz.chapterName,
                correctCount = quiz.correctCount,
                wrongCount = quiz.wrongCount,
                skippedCount = quiz.totalSkipped,
                totalAnsweredOrPlayable = quiz.totalPlayable,
                durationSeconds = durationSeconds,
                wrongMcqs = quiz.wrongMcqs
            )
            _quizResultState.value = resultState
            _activeQuizState.value = null

            viewModelScope.launch {
                repository.saveQuizSession(
                    subjectId = quiz.subjectId,
                    chapterId = quiz.chapterId,
                    score = quiz.correctCount,
                    total = quiz.totalPlayable,
                    wrongCount = quiz.wrongCount,
                    skippedCount = quiz.totalSkipped,
                    durationSeconds = durationSeconds
                )
            }
            onQuizFinished()
        }
    }

    fun retryWrongAnswers(onStarted: () -> Unit) {
        val result = _quizResultState.value ?: return
        if (result.wrongMcqs.isEmpty()) return

        val subject = subjectsWithStats.value.find { it.id == result.subjectId }
        _activeQuizState.value = ActiveQuizState(
            subjectId = result.subjectId,
            subjectName = result.subjectName,
            subjectEmoji = subject?.iconEmoji ?: "📘",
            chapterId = null,
            chapterName = result.chapterName,
            questions = result.wrongMcqs.shuffled(),
            currentIndex = 0,
            startTimeMillis = System.currentTimeMillis(),
            isRetryMode = true
        )
        _quizResultState.value = null
        onStarted()
    }

    fun cancelActiveQuiz() {
        _activeQuizState.value = null
    }

    // History filter
    fun setHistorySubjectFilter(subjectId: Long?) {
        _historySubjectFilter.value = subjectId
    }

    // Settings actions
    fun saveApiKey(key: String) {
        viewModelScope.launch {
            repository.saveApiKey(key)
            _settingsTestState.value = SettingsTestState()
        }
    }

    fun testApiConnection(key: String) {
        viewModelScope.launch {
            _settingsTestState.value = SettingsTestState(isTesting = true)
            val res = repository.testApiConnection(key)
            res.fold(
                onSuccess = {
                    _settingsTestState.value = SettingsTestState(
                        isTesting = false,
                        testMessage = "Connected to Gemini 1.5 Flash!",
                        isError = false
                    )
                },
                onFailure = { err ->
                    _settingsTestState.value = SettingsTestState(
                        isTesting = false,
                        testMessage = err.message ?: "Connection failed.",
                        isError = true
                    )
                }
            )
        }
    }

    fun setSoundEffects(enabled: Boolean) {
        viewModelScope.launch { repository.setSoundEffects(enabled) }
    }

    fun setExplanationMode(mode: ExplanationMode) {
        viewModelScope.launch { repository.setExplanationMode(mode) }
    }

    fun setLanguage(language: AppLanguage) {
        viewModelScope.launch { repository.setLanguage(language) }
    }

    override fun onCleared() {
        super.onCleared()
        soundEffectHelper.release()
    }

    companion object {
        private val VALID_ANSWERS = setOf("A", "B", "C", "D")
    }
}

class MainViewModelFactory(
    private val repository: McqRepository,
    private val soundEffectHelper: SoundEffectHelper
) : ViewModelProvider.Factory {
    @Suppress("UNCHECKED_CAST")
    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        if (modelClass.isAssignableFrom(MainViewModel::class.java)) {
            return MainViewModel(repository, soundEffectHelper) as T
        }
        throw IllegalArgumentException("Unknown ViewModel class: ${modelClass.name}")
    }
}
