package com.example.ui.screens

import android.content.res.Configuration
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Cancel
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.SkipNext
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import com.example.data.local.AppLanguage
import com.example.ui.QuizResultState
import com.example.ui.components.ElevatedBrandCard
import com.example.ui.components.PrimaryActionButton
import com.example.ui.components.SecondaryActionButton
import com.example.ui.theme.BorderOutline
import com.example.ui.theme.CorrectGreen
import com.example.ui.theme.CorrectGreenBg
import com.example.ui.theme.MCQMasterTheme
import com.example.ui.theme.WarningOrange
import com.example.ui.theme.WarningOrangeBg
import com.example.ui.theme.WrongRed
import com.example.ui.theme.WrongRedBg
import com.example.util.AppStrings
import com.example.util.LocalizedStrings

@Composable
fun ResultsScreen(
    resultState: QuizResultState?,
    strings: LocalizedStrings,
    onRetryWrongAnswers: () -> Unit,
    onBackToHome: () -> Unit,
    modifier: Modifier = Modifier
) {
    if (resultState == null) {
        Box(modifier = modifier.fillMaxSize())
        return
    }

    val percentage = resultState.percentage
    val scoreColor = when {
        percentage >= 60 -> CorrectGreen
        percentage >= 40 -> WarningOrange
        else -> WrongRed
    }
    val encouragement = when {
        percentage >= 60 -> strings.greatJobMsg
        percentage >= 40 -> strings.keepPracticingMsg
        else -> strings.needsReviewMsg
    }

    var targetSweep by remember { mutableFloatStateOf(0f) }
    LaunchedEffect(percentage) {
        targetSweep = (percentage.coerceIn(0, 100) / 100f) * 360f
    }
    val animatedSweep by animateFloatAsState(
        targetValue = targetSweep,
        animationSpec = tween(durationMillis = 700),
        label = "score_ring_sweep"
    )

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background),
        contentAlignment = Alignment.TopCenter
    ) {
        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(16.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(20.dp)
        ) {
            if (resultState.subjectName.isNotBlank()) {
                item(key = "result_header") {
                    Text(
                        text = resultState.subjectName + (resultState.chapterName?.let { " • $it" } ?: ""),
                        style = MaterialTheme.typography.titleMedium,
                        color = MaterialTheme.colorScheme.secondary,
                        textAlign = TextAlign.Center
                    )
                }
            }

            item(key = "result_circle") {
                Box(
                    modifier = Modifier
                        .size(210.dp)
                        .testTag("results_score_circle"),
                    contentAlignment = Alignment.Center
                ) {
                    Canvas(modifier = Modifier.fillMaxSize()) {
                        val strokeWidth = 18.dp.toPx()
                        drawArc(
                            color = BorderOutline,
                            startAngle = -90f,
                            sweepAngle = 360f,
                            useCenter = false,
                            style = Stroke(width = strokeWidth, cap = StrokeCap.Round)
                        )
                        drawArc(
                            color = scoreColor,
                            startAngle = -90f,
                            sweepAngle = animatedSweep,
                            useCenter = false,
                            style = Stroke(width = strokeWidth, cap = StrokeCap.Round)
                        )
                    }
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(
                            text = "$percentage%",
                            style = MaterialTheme.typography.displaySmall,
                            color = scoreColor,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = "${resultState.correctCount}/${resultState.totalAnsweredOrPlayable}",
                            style = MaterialTheme.typography.titleLarge,
                            color = MaterialTheme.colorScheme.onBackground,
                            fontWeight = FontWeight.SemiBold
                        )
                    }
                }
            }

            item(key = "result_message") {
                Text(
                    text = encouragement,
                    style = MaterialTheme.typography.titleMedium,
                    textAlign = TextAlign.Center,
                    color = MaterialTheme.colorScheme.onBackground
                )
            }

            item(key = "result_stats") {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    ResultStatCard(
                        icon = Icons.Default.CheckCircle,
                        count = resultState.correctCount,
                        label = strings.statCorrect,
                        accent = CorrectGreen,
                        bg = CorrectGreenBg,
                        modifier = Modifier.weight(1f)
                    )
                    ResultStatCard(
                        icon = Icons.Default.Cancel,
                        count = resultState.wrongCount,
                        label = strings.statWrong,
                        accent = WrongRed,
                        bg = WrongRedBg,
                        modifier = Modifier.weight(1f)
                    )
                    ResultStatCard(
                        icon = Icons.Default.SkipNext,
                        count = resultState.skippedCount,
                        label = strings.statSkipped,
                        accent = WarningOrange,
                        bg = WarningOrangeBg,
                        modifier = Modifier.weight(1f)
                    )
                }
            }

            if (resultState.wrongMcqs.isNotEmpty()) {
                item(key = "retry_wrong_btn") {
                    PrimaryActionButton(
                        text = "${strings.retryWrongAnswers} (${resultState.wrongMcqs.size})",
                        onClick = onRetryWrongAnswers,
                        icon = Icons.Default.Refresh,
                        containerColor = WarningOrange,
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("retry_wrong_answers_button")
                    )
                }
            }

            item(key = "back_home_btn") {
                Spacer(Modifier.height(4.dp))
                SecondaryActionButton(
                    text = strings.backToHome,
                    onClick = onBackToHome,
                    icon = Icons.Default.Home,
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("results_back_home_button")
                )
            }
        }
    }
}

@Composable
private fun ResultStatCard(
    icon: ImageVector,
    count: Int,
    label: String,
    accent: Color,
    bg: Color,
    modifier: Modifier = Modifier
) {
    ElevatedBrandCard(modifier = modifier) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            Box(
                modifier = Modifier
                    .size(36.dp)
                    .clip(CircleShape)
                    .background(bg),
                contentAlignment = Alignment.Center
            ) {
                Icon(icon, contentDescription = label, tint = accent, modifier = Modifier.size(20.dp))
            }
            Text(
                text = count.toString(),
                style = MaterialTheme.typography.headlineSmall,
                color = accent,
                fontWeight = FontWeight.Bold
            )
            Text(
                text = label,
                style = MaterialTheme.typography.labelMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
    }
}

@Preview(
    showBackground = true,
    showSystemUi = true,
    device = "spec:width=360dp,height=800dp,dpi=420",
    uiMode = Configuration.UI_MODE_NIGHT_NO
)
@Composable
private fun ResultsScreenPreview() {
    MCQMasterTheme {
        ResultsScreen(
            resultState = QuizResultState(
                subjectId = 1L,
                subjectName = "Physics",
                chapterName = "Chapter 3",
                correctCount = 19,
                wrongCount = 5,
                skippedCount = 1,
                totalAnsweredOrPlayable = 25,
                durationSeconds = 180
            ),
            strings = AppStrings.get(AppLanguage.ENGLISH),
            onRetryWrongAnswers = {},
            onBackToHome = {}
        )
    }
}
