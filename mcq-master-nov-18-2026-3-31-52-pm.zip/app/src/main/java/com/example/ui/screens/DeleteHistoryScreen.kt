package com.example.ui.screens

import android.content.res.Configuration
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.defaultMinSize
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.History
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Checkbox
import androidx.compose.material3.CheckboxDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.PrimaryTabRow
import androidx.compose.material3.Surface
import androidx.compose.material3.Tab
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.local.AppLanguage
import com.example.data.local.InputHistoryItem
import com.example.data.local.QuizSessionWithMeta
import com.example.ui.UiState
import com.example.ui.components.ElevatedBrandCard
import com.example.ui.components.ListShimmerPlaceholder
import com.example.ui.components.PrimaryActionButton
import com.example.ui.theme.BorderOutline
import com.example.ui.theme.MCQMasterTheme
import com.example.ui.theme.PrimaryBlue
import com.example.ui.theme.PrimaryBlueLight
import com.example.ui.theme.WrongRed
import com.example.ui.theme.WrongRedBg
import com.example.util.AppStrings
import com.example.util.LocalizedStrings
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DeleteHistoryScreen(
    inputHistoryState: UiState<List<InputHistoryItem>>,
    outputHistoryState: UiState<List<QuizSessionWithMeta>>,
    strings: LocalizedStrings,
    onDeleteInputChapters: (List<Long>) -> Unit,
    onDeleteOutputSessions: (List<Long>) -> Unit,
    modifier: Modifier = Modifier
) {
    var selectedTab by rememberSaveable { mutableIntStateOf(0) }
    var selectedInputIds by remember { mutableStateOf(emptySet<Long>()) }
    var selectedOutputIds by remember { mutableStateOf(emptySet<Long>()) }
    var showConfirmDialog by remember { mutableStateOf(false) }

    val inputListState = rememberLazyListState()
    val outputListState = rememberLazyListState()
    val dateFormatter = remember { SimpleDateFormat("dd MMM yyyy • hh:mm a", Locale.getDefault()) }

    val currentSelectedCount by remember(selectedTab, selectedInputIds, selectedOutputIds) {
        derivedStateOf {
            if (selectedTab == 0) selectedInputIds.size else selectedOutputIds.size
        }
    }

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background),
        contentAlignment = Alignment.TopCenter
    ) {
        Column(modifier = Modifier.fillMaxSize()) {
            PrimaryTabRow(
                selectedTabIndex = selectedTab,
                containerColor = MaterialTheme.colorScheme.background,
                contentColor = PrimaryBlue
            ) {
                Tab(
                    selected = selectedTab == 0,
                    onClick = { selectedTab = 0 },
                    text = {
                        Text(
                            text = strings.inputHistoryTab,
                            fontWeight = if (selectedTab == 0) FontWeight.Bold else FontWeight.Medium
                        )
                    },
                    modifier = Modifier
                        .defaultMinSize(minHeight = 52.dp)
                        .testTag("tab_input_history")
                )
                Tab(
                    selected = selectedTab == 1,
                    onClick = { selectedTab = 1 },
                    text = {
                        Text(
                            text = strings.outputHistoryTab,
                            fontWeight = if (selectedTab == 1) FontWeight.Bold else FontWeight.Medium
                        )
                    },
                    modifier = Modifier
                        .defaultMinSize(minHeight = 52.dp)
                        .testTag("tab_output_history")
                )
            }

            Box(modifier = Modifier.weight(1f)) {
                if (selectedTab == 0) {
                    InputHistoryTabContent(
                        state = inputHistoryState,
                        selectedIds = selectedInputIds,
                        listState = inputListState,
                        dateFormatter = dateFormatter,
                        strings = strings,
                        onToggleItem = { id ->
                            selectedInputIds = if (id in selectedInputIds) {
                                selectedInputIds - id
                            } else {
                                selectedInputIds + id
                            }
                        },
                        onToggleSelectAll = { allIds ->
                            selectedInputIds = if (selectedInputIds.size == allIds.size && allIds.isNotEmpty()) {
                                emptySet()
                            } else {
                                allIds.toSet()
                            }
                        }
                    )
                } else {
                    OutputHistoryTabContent(
                        state = outputHistoryState,
                        selectedIds = selectedOutputIds,
                        listState = outputListState,
                        dateFormatter = dateFormatter,
                        strings = strings,
                        onToggleItem = { id ->
                            selectedOutputIds = if (id in selectedOutputIds) {
                                selectedOutputIds - id
                            } else {
                                selectedOutputIds + id
                            }
                        },
                        onToggleSelectAll = { allIds ->
                            selectedOutputIds = if (selectedOutputIds.size == allIds.size && allIds.isNotEmpty()) {
                                emptySet()
                            } else {
                                allIds.toSet()
                            }
                        }
                    )
                }
            }

            AnimatedVisibility(
                visible = currentSelectedCount > 0,
                enter = slideInVertically { it } + fadeIn(),
                exit = slideOutVertically { it } + fadeOut()
            ) {
                Surface(
                    shadowElevation = 8.dp,
                    color = MaterialTheme.colorScheme.background,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    PrimaryActionButton(
                        text = strings.deleteSelectedButton(currentSelectedCount),
                        onClick = { showConfirmDialog = true },
                        icon = Icons.Default.Delete,
                        containerColor = WrongRed,
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(16.dp)
                            .testTag("delete_selected_history_button")
                    )
                }
            }
        }
    }

    if (showConfirmDialog && currentSelectedCount > 0) {
        AlertDialog(
            onDismissRequest = { showConfirmDialog = false },
            containerColor = MaterialTheme.colorScheme.background,
            shape = RoundedCornerShape(16.dp),
            title = { Text(strings.deleteSelectedConfirmTitle) },
            text = { Text(strings.deleteSelectedConfirmBody(currentSelectedCount)) },
            confirmButton = {
                Button(
                    onClick = {
                        showConfirmDialog = false
                        if (selectedTab == 0) {
                            val ids = selectedInputIds.toList()
                            selectedInputIds = emptySet()
                            onDeleteInputChapters(ids)
                        } else {
                            val ids = selectedOutputIds.toList()
                            selectedOutputIds = emptySet()
                            onDeleteOutputSessions(ids)
                        }
                    },
                    shape = RoundedCornerShape(12.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = WrongRed),
                    modifier = Modifier
                        .defaultMinSize(minHeight = 48.dp)
                        .testTag("confirm_delete_selected_button")
                ) {
                    Text(strings.delete)
                }
            },
            dismissButton = {
                TextButton(
                    onClick = { showConfirmDialog = false },
                    modifier = Modifier.defaultMinSize(minHeight = 48.dp)
                ) {
                    Text(strings.cancel)
                }
            }
        )
    }
}

@Composable
private fun InputHistoryTabContent(
    state: UiState<List<InputHistoryItem>>,
    selectedIds: Set<Long>,
    listState: androidx.compose.foundation.lazy.LazyListState,
    dateFormatter: SimpleDateFormat,
    strings: LocalizedStrings,
    onToggleItem: (Long) -> Unit,
    onToggleSelectAll: (List<Long>) -> Unit
) {
    when (state) {
        is UiState.Loading -> ListShimmerPlaceholder()
        is UiState.Error -> Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(24.dp),
            contentAlignment = Alignment.Center
        ) {
            Text(state.message, color = WrongRed)
        }
        is UiState.Success -> {
            val itemsList = state.data
            if (itemsList.isEmpty()) {
                EmptyDeleteHistoryState(message = strings.noHistoryFound)
            } else {
                val allIds = remember(itemsList) { itemsList.map { it.chapterId } }
                val allSelected = selectedIds.size == allIds.size && allIds.isNotEmpty()

                LazyColumn(
                    state = listState,
                    modifier = Modifier.fillMaxSize(),
                    contentPadding = PaddingValues(16.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    item(key = "input_select_all_header") {
                        SelectAllHeaderRow(
                            allSelected = allSelected,
                            selectedCount = selectedIds.size,
                            totalCount = itemsList.size,
                            strings = strings,
                            onToggleAll = { onToggleSelectAll(allIds) }
                        )
                    }

                    items(itemsList, key = { it.chapterId }) { item ->
                        val isSelected = item.chapterId in selectedIds
                        InputHistorySelectableRow(
                            item = item,
                            isSelected = isSelected,
                            formattedDate = remember(item.createdAt) {
                                dateFormatter.format(Date(item.createdAt))
                            },
                            extractedLabel = strings.extractedCountLabel(item.mcqCount),
                            onClick = { onToggleItem(item.chapterId) }
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun OutputHistoryTabContent(
    state: UiState<List<QuizSessionWithMeta>>,
    selectedIds: Set<Long>,
    listState: androidx.compose.foundation.lazy.LazyListState,
    dateFormatter: SimpleDateFormat,
    strings: LocalizedStrings,
    onToggleItem: (Long) -> Unit,
    onToggleSelectAll: (List<Long>) -> Unit
) {
    when (state) {
        is UiState.Loading -> ListShimmerPlaceholder()
        is UiState.Error -> Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(24.dp),
            contentAlignment = Alignment.Center
        ) {
            Text(state.message, color = WrongRed)
        }
        is UiState.Success -> {
            val itemsList = state.data
            if (itemsList.isEmpty()) {
                EmptyDeleteHistoryState(message = strings.noHistoryFound)
            } else {
                val allIds = remember(itemsList) { itemsList.map { it.id } }
                val allSelected = selectedIds.size == allIds.size && allIds.isNotEmpty()

                LazyColumn(
                    state = listState,
                    modifier = Modifier.fillMaxSize(),
                    contentPadding = PaddingValues(16.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    item(key = "output_select_all_header") {
                        SelectAllHeaderRow(
                            allSelected = allSelected,
                            selectedCount = selectedIds.size,
                            totalCount = itemsList.size,
                            strings = strings,
                            onToggleAll = { onToggleSelectAll(allIds) }
                        )
                    }

                    items(itemsList, key = { it.id }) { session ->
                        val isSelected = session.id in selectedIds
                        OutputHistorySelectableRow(
                            session = session,
                            isSelected = isSelected,
                            formattedDate = remember(session.dateTaken) {
                                dateFormatter.format(Date(session.dateTaken))
                            },
                            allChaptersLabel = strings.allChapters,
                            onClick = { onToggleItem(session.id) }
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun SelectAllHeaderRow(
    allSelected: Boolean,
    selectedCount: Int,
    totalCount: Int,
    strings: LocalizedStrings,
    onToggleAll: () -> Unit
) {
    Surface(
        onClick = onToggleAll,
        shape = RoundedCornerShape(12.dp),
        color = PrimaryBlueLight,
        modifier = Modifier
            .fillMaxWidth()
            .defaultMinSize(minHeight = 52.dp)
            .testTag("select_all_toggle")
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 12.dp, vertical = 6.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Checkbox(
                checked = allSelected,
                onCheckedChange = { onToggleAll() },
                colors = CheckboxDefaults.colors(checkedColor = PrimaryBlue)
            )
            Spacer(Modifier.width(6.dp))
            Text(
                text = if (allSelected) strings.deselectAll else strings.selectAll,
                style = MaterialTheme.typography.titleSmall,
                color = PrimaryBlue,
                fontWeight = FontWeight.Bold,
                modifier = Modifier.weight(1f)
            )
            Text(
                text = "$selectedCount / $totalCount",
                style = MaterialTheme.typography.labelMedium,
                color = PrimaryBlue
            )
        }
    }
}

@Composable
private fun InputHistorySelectableRow(
    item: InputHistoryItem,
    isSelected: Boolean,
    formattedDate: String,
    extractedLabel: String,
    onClick: () -> Unit
) {
    ElevatedBrandCard(
        onClick = onClick,
        containerColor = if (isSelected) WrongRedBg else MaterialTheme.colorScheme.surface,
        border = BorderStroke(
            width = if (isSelected) 1.5.dp else 1.dp,
            color = if (isSelected) WrongRed.copy(alpha = 0.6f) else BorderOutline
        ),
        modifier = Modifier
            .fillMaxWidth()
            .testTag("input_history_item_${item.chapterId}")
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .defaultMinSize(minHeight = 64.dp)
                .padding(horizontal = 10.dp, vertical = 12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Checkbox(
                checked = isSelected,
                onCheckedChange = { onClick() },
                colors = CheckboxDefaults.colors(checkedColor = WrongRed)
            )
            Spacer(Modifier.width(6.dp))
            Box(
                modifier = Modifier
                    .size(42.dp)
                    .background(
                        if (isSelected) Color.White else PrimaryBlueLight,
                        RoundedCornerShape(10.dp)
                    ),
                contentAlignment = Alignment.Center
            ) {
                Text(text = item.subjectEmoji, fontSize = 20.sp)
            }
            Spacer(Modifier.width(12.dp))
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = item.subjectName,
                    style = MaterialTheme.typography.labelMedium,
                    color = PrimaryBlue,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    text = item.chapterName,
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.SemiBold,
                    color = MaterialTheme.colorScheme.onBackground
                )
                Spacer(Modifier.height(2.dp))
                Text(
                    text = "$extractedLabel • $formattedDate",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }
    }
}

@Composable
private fun OutputHistorySelectableRow(
    session: QuizSessionWithMeta,
    isSelected: Boolean,
    formattedDate: String,
    allChaptersLabel: String,
    onClick: () -> Unit
) {
    val pct = if (session.total > 0) (session.score * 100) / session.total else 0
    val chapterTitle = session.chapterName ?: allChaptersLabel
    ElevatedBrandCard(
        onClick = onClick,
        containerColor = if (isSelected) WrongRedBg else MaterialTheme.colorScheme.surface,
        border = BorderStroke(
            width = if (isSelected) 1.5.dp else 1.dp,
            color = if (isSelected) WrongRed.copy(alpha = 0.6f) else BorderOutline
        ),
        modifier = Modifier
            .fillMaxWidth()
            .testTag("output_history_item_${session.id}")
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .defaultMinSize(minHeight = 64.dp)
                .padding(horizontal = 10.dp, vertical = 12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Checkbox(
                checked = isSelected,
                onCheckedChange = { onClick() },
                colors = CheckboxDefaults.colors(checkedColor = WrongRed)
            )
            Spacer(Modifier.width(6.dp))
            Box(
                modifier = Modifier
                    .size(42.dp)
                    .background(
                        if (isSelected) Color.White else PrimaryBlueLight,
                        RoundedCornerShape(10.dp)
                    ),
                contentAlignment = Alignment.Center
            ) {
                Text(text = session.subjectEmoji, fontSize = 20.sp)
            }
            Spacer(Modifier.width(12.dp))
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = "${session.subjectName} • $chapterTitle",
                    style = MaterialTheme.typography.titleSmall,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onBackground
                )
                Text(
                    text = "${session.score}/${session.total} — $pct%",
                    style = MaterialTheme.typography.bodyMedium,
                    fontWeight = FontWeight.SemiBold,
                    color = PrimaryBlue
                )
                Text(
                    text = formattedDate,
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }
    }
}

@Composable
private fun EmptyDeleteHistoryState(message: String) {
    Box(
        modifier = Modifier
            .fillMaxSize()
            .padding(24.dp),
        contentAlignment = Alignment.Center
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Icon(
                imageVector = Icons.Default.History,
                contentDescription = message,
                tint = PrimaryBlue.copy(alpha = 0.5f),
                modifier = Modifier.size(56.dp)
            )
            Text(
                text = message,
                style = MaterialTheme.typography.titleMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                textAlign = TextAlign.Center
            )
        }
    }
}

@Preview(
    showBackground = true,
    showSystemUi = true,
    device = "spec:width=360dp,height=800dp,dpi=420",
    uiMode = Configuration.UI_MODE_NIGHT_NO
)
@Composable
private fun DeleteHistoryScreenPreview() {
    MCQMasterTheme {
        DeleteHistoryScreen(
            inputHistoryState = UiState.Success(
                listOf(
                    InputHistoryItem(
                        chapterId = 1L,
                        subjectId = 1L,
                        subjectName = "Physics",
                        subjectEmoji = "⚛️",
                        chapterName = "Chapter 2: Motion",
                        mcqCount = 25,
                        createdAt = 1730000000000L
                    )
                )
            ),
            outputHistoryState = UiState.Success(emptyList()),
            strings = AppStrings.get(AppLanguage.ENGLISH),
            onDeleteInputChapters = {},
            onDeleteOutputSessions = {}
        )
    }
}
