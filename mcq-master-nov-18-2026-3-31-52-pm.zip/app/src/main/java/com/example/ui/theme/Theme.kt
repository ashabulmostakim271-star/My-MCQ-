package com.example.ui.theme

import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp

private val MCQMasterLightColorScheme = lightColorScheme(
    primary = PrimaryBlue,
    onPrimary = Color.White,
    primaryContainer = PrimaryBlueLight,
    onPrimaryContainer = PrimaryBlueDark,
    secondary = SecondaryTeal,
    onSecondary = Color.White,
    secondaryContainer = SecondaryTealLight,
    onSecondaryContainer = Color(0xFF004D56),
    tertiary = CorrectGreen,
    onTertiary = Color.White,
    tertiaryContainer = CorrectGreenBg,
    onTertiaryContainer = CorrectGreen,
    error = WrongRed,
    onError = Color.White,
    errorContainer = WrongRedBg,
    onErrorContainer = WrongRed,
    background = BackgroundWhite,
    onBackground = TextPrimary,
    surface = SurfaceLight,
    onSurface = TextPrimary,
    surfaceVariant = Color(0xFFEEF2F7),
    onSurfaceVariant = TextSecondary,
    surfaceContainerLowest = BackgroundWhite,
    surfaceContainerLow = SurfaceLight,
    surfaceContainer = Color(0xFFF1F4F8),
    surfaceContainerHigh = Color(0xFFEAF0F6),
    outline = BorderOutline,
    outlineVariant = Color(0xFFE5EAF1)
)

val MCQMasterShapes = Shapes(
    extraSmall = RoundedCornerShape(8.dp),
    small = RoundedCornerShape(12.dp),
    medium = RoundedCornerShape(16.dp),
    large = RoundedCornerShape(16.dp),
    extraLarge = RoundedCornerShape(24.dp)
)

@Composable
fun MCQMasterTheme(
    content: @Composable () -> Unit
) {
    MaterialTheme(
        colorScheme = MCQMasterLightColorScheme,
        typography = MCQMasterTypography,
        shapes = MCQMasterShapes,
        content = content
    )
}
