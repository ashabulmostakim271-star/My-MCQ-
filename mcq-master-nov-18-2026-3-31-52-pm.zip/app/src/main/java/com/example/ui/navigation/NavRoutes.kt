package com.example.ui.navigation

import kotlinx.serialization.Serializable

@Serializable
sealed interface NavRoute {
    @Serializable
    data object Home : NavRoute

    @Serializable
    data object Practice : NavRoute

    @Serializable
    data object History : NavRoute

    @Serializable
    data object Settings : NavRoute

    @Serializable
    data object ImportMcq : NavRoute

    @Serializable
    data object ManageSubjects : NavRoute

    @Serializable
    data object DeleteHistory : NavRoute

    @Serializable
    data object Quiz : NavRoute

    @Serializable
    data object Results : NavRoute

    @Serializable
    data object About : NavRoute
}
