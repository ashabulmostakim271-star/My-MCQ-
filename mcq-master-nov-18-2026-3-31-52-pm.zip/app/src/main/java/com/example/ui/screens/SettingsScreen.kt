package com.example.ui.screens

import android.content.res.Configuration
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.defaultMinSize
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyListState
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.KeyboardArrowRight
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.DeleteSweep
import androidx.compose.material.icons.filled.Error
import androidx.compose.material.icons.filled.Key
import androidx.compose.material.icons.filled.Language
import androidx.compose.material.icons.filled.MenuBook
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material.icons.filled.VisibilityOff
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import com.example.data.local.ApiKeyStatus
import com.example.data.local.AppLanguage
import com.example.data.local.AppPreferences
import com.example.data.local.ExplanationMode
import com.example.ui.SettingsTestState
import com.example.ui.components.ElevatedBrandCard
import com.example.ui.components.PrimaryActionButton
import com.example.ui.theme.CorrectGreen
import com.example.ui.theme.CorrectGreenBg
import com.example.ui.theme.MCQMasterTheme
import com.example.ui.theme.PrimaryBlue
import com.example.ui.theme.PrimaryBlueLight
import com.example.ui.theme.WarningOrange
import com.example.ui.theme.WarningOrangeBg
import com.example.ui.theme.WrongRed
import com.example.ui.theme.WrongRedBg
import com.example.util.AppStrings
import com.example.util.LocalizedStrings

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun SettingsScreen(
    storedApiKey: String,
    apiStatus: ApiKeyStatus,
    testState: SettingsTestState,
    preferences: AppPreferences,
    listState: LazyListState,
    strings: LocalizedStrings,
    onSaveApiKey: (String) -> Unit,
    onTestConnection: (String) -> Unit,
    onSoundEffectsChange: (Boolean) -> Unit,
    onExplanationModeChange: (ExplanationMode) -> Unit,
    onLanguageChange: (AppLanguage) -> Unit,
    onOpenDeleteHistory: () -> Unit,
    modifier: Modifier = Modifier
) {
    var apiKeyInput by remember(storedApiKey) { mutableStateOf(storedApiKey) }
    var showKeyPlain by remember { mutableStateOf(false) }

    LaunchedEffect(storedApiKey) {
        if (apiKeyInput != storedApiKey && storedApiKey.isNotEmpty()) {
            apiKeyInput = storedApiKey
        }
    }

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background),
        contentAlignment = Alignment.TopCenter
    ) {
        LazyColumn(
            state = listState,
            modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            item(key = "settings_api_key_card") {
                ApiKeySettingsCard(
                    apiKeyInput = apiKeyInput,
                    onApiKeyInputChange = { apiKeyInput = it },
                    showKeyPlain = showKeyPlain,
                    onTogglePlain = { showKeyPlain = !showKeyPlain },
                    apiStatus = apiStatus,
                    testState = testState,
                    strings = strings,
                    onSaveApiKey = { onSaveApiKey(apiKeyInput) },
                    onTestConnection = { onTestConnection(apiKeyInput) }
                )
            }

            item(key = "settings_sound_card") {
                ElevatedBrandCard {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 16.dp, vertical = 12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(Icons.Default.VolumeUp, contentDescription = null, tint = PrimaryBlue)
                        Spacer(Modifier.width(12.dp))
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = strings.soundEffectsTitle,
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.SemiBold
                            )
                            Text(
                                text = strings.soundEffectsSubtitle,
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                        Switch(
                            checked = preferences.soundEffectsEnabled,
                            onCheckedChange = onSoundEffectsChange,
                            modifier = Modifier.testTag("sound_effects_switch")
                        )
                    }
                }
            }

            item(key = "settings_explanation_card") {
                ElevatedBrandCard {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.MenuBook, contentDescription = null, tint = PrimaryBlue)
                            Spacer(Modifier.width(8.dp))
                            Text(
                                text = strings.showExplanationTitle,
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.SemiBold
                            )
                        }
                        FlowRow(
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                            verticalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            listOf(
                                ExplanationMode.ALWAYS to strings.explanationAlways,
                                ExplanationMode.ON_WRONG_ONLY to strings.explanationOnWrong,
                                ExplanationMode.NEVER to strings.explanationNever
                            ).forEach { (mode, label) ->
                                FilterChip(
                                    selected = preferences.explanationMode == mode,
                                    onClick = { onExplanationModeChange(mode) },
                                    label = { Text(label) },
                                    colors = FilterChipDefaults.filterChipColors(
                                        selectedContainerColor = PrimaryBlueLight,
                                        selectedLabelColor = PrimaryBlue
                                    ),
                                    modifier = Modifier
                                        .heightIn(min = 52.dp)
                                        .testTag("explanation_chip_${mode.name.lowercase()}")
                                )
                            }
                        }
                    }
                }
            }

            item(key = "settings_language_card") {
                ElevatedBrandCard {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.Language, contentDescription = null, tint = PrimaryBlue)
                            Spacer(Modifier.width(8.dp))
                            Text(
                                text = strings.languageTitle,
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.SemiBold
                            )
                        }
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            FilterChip(
                                selected = preferences.language == AppLanguage.ENGLISH,
                                onClick = { onLanguageChange(AppLanguage.ENGLISH) },
                                label = { Text("English") },
                                colors = FilterChipDefaults.filterChipColors(
                                    selectedContainerColor = PrimaryBlueLight,
                                    selectedLabelColor = PrimaryBlue
                                ),
                                modifier = Modifier
                                    .weight(1f)
                                    .heightIn(min = 52.dp)
                                    .testTag("language_chip_english")
                            )
                            FilterChip(
                                selected = preferences.language == AppLanguage.BENGALI,
                                onClick = { onLanguageChange(AppLanguage.BENGALI) },
                                label = { Text("বাংলা") },
                                colors = FilterChipDefaults.filterChipColors(
                                    selectedContainerColor = PrimaryBlueLight,
                                    selectedLabelColor = PrimaryBlue
                                ),
                                modifier = Modifier
                                    .weight(1f)
                                    .heightIn(min = 52.dp)
                                    .testTag("language_chip_bengali")
                            )
                        }
                    }
                }
            }

            // Dedicated "Delete History" navigation option (replaces old Delete All Data button)
            item(key = "settings_delete_history_option") {
                ElevatedBrandCard(
                    onClick = onOpenDeleteHistory,
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("settings_delete_history_option")
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .defaultMinSize(minHeight = 64.dp)
                            .padding(horizontal = 16.dp, vertical = 14.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = Icons.Default.DeleteSweep,
                            contentDescription = strings.deleteHistoryTitle,
                            tint = WrongRed
                        )
                        Spacer(Modifier.width(12.dp))
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = strings.deleteHistoryTitle,
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.SemiBold,
                                color = MaterialTheme.colorScheme.onBackground
                            )
                            Text(
                                text = strings.deleteHistorySubtitle,
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.KeyboardArrowRight,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }

            item(key = "settings_bottom_spacer") {
                Spacer(Modifier.height(12.dp))
            }
        }
    }
}

@Composable
private fun ApiKeySettingsCard(
    apiKeyInput: String,
    onApiKeyInputChange: (String) -> Unit,
    showKeyPlain: Boolean,
    onTogglePlain: () -> Unit,
    apiStatus: ApiKeyStatus,
    testState: SettingsTestState,
    strings: LocalizedStrings,
    onSaveApiKey: () -> Unit,
    onTestConnection: () -> Unit
) {
    ElevatedBrandCard {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.Key, contentDescription = null, tint = PrimaryBlue)
                Spacer(Modifier.width(8.dp))
                Text(
                    text = strings.apiKeySectionTitle,
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold
                )
            }

            val (statusText, statusColor, statusBg, statusIcon) = when (apiStatus) {
                ApiKeyStatus.CONNECTED -> Quad(
                    "✅ ${strings.statusConnected}",
                    CorrectGreen,
                    CorrectGreenBg,
                    Icons.Default.CheckCircle
                )
                ApiKeyStatus.SAVED_UNVERIFIED -> Quad(
                    strings.statusSavedUnverified,
                    WarningOrange,
                    WarningOrangeBg,
                    Icons.Default.Key
                )
                ApiKeyStatus.NOT_SET -> Quad(
                    "❌ ${strings.statusNotSet}",
                    WrongRed,
                    WrongRedBg,
                    Icons.Default.Error
                )
            }

            Surface(
                shape = RoundedCornerShape(10.dp),
                color = statusBg,
                modifier = Modifier.testTag("api_key_status_badge")
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        imageVector = statusIcon,
                        contentDescription = null,
                        tint = statusColor,
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(Modifier.width(6.dp))
                    Text(
                        text = statusText,
                        style = MaterialTheme.typography.labelMedium,
                        color = statusColor,
                        fontWeight = FontWeight.Bold
                    )
                }
            }

            OutlinedTextField(
                value = apiKeyInput,
                onValueChange = onApiKeyInputChange,
                label = { Text(strings.apiKeyHint) },
                singleLine = true,
                visualTransformation = if (showKeyPlain) {
                    VisualTransformation.None
                } else {
                    PasswordVisualTransformation()
                },
                trailingIcon = {
                    IconButton(
                        onClick = onTogglePlain,
                        modifier = Modifier.size(48.dp)
                    ) {
                        Icon(
                            imageVector = if (showKeyPlain) Icons.Default.VisibilityOff else Icons.Default.Visibility,
                            contentDescription = "Toggle API key visibility"
                        )
                    }
                },
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("gemini_api_key_input")
            )

            Text(
                text = strings.apiKeyHelper,
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                OutlinedButton(
                    onClick = onSaveApiKey,
                    shape = RoundedCornerShape(12.dp),
                    border = BorderStroke(1.5.dp, PrimaryBlue),
                    modifier = Modifier
                        .weight(1f)
                        .defaultMinSize(minHeight = 52.dp)
                        .testTag("save_api_key_button")
                ) {
                    Text(strings.saveKey)
                }
                PrimaryActionButton(
                    text = if (testState.isTesting) strings.testingConnection else strings.testConnection,
                    onClick = onTestConnection,
                    enabled = !testState.isTesting && apiKeyInput.isNotBlank(),
                    modifier = Modifier
                        .weight(1.3f)
                        .testTag("test_connection_button")
                )
            }

            if (testState.isTesting) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    CircularProgressIndicator(modifier = Modifier.size(18.dp), strokeWidth = 2.dp)
                    Spacer(Modifier.width(8.dp))
                    Text(strings.testingConnection, style = MaterialTheme.typography.bodySmall)
                }
            } else if (testState.testMessage != null) {
                Text(
                    text = testState.testMessage,
                    style = MaterialTheme.typography.bodySmall,
                    color = if (testState.isError) WrongRed else CorrectGreen,
                    fontWeight = FontWeight.SemiBold
                )
            }
        }
    }
}

private data class Quad<A, B, C, D>(val first: A, val second: B, val third: C, val fourth: D)

@Preview(
    showBackground = true,
    showSystemUi = true,
    device = "spec:width=360dp,height=800dp,dpi=420",
    uiMode = Configuration.UI_MODE_NIGHT_NO
)
@Composable
private fun SettingsScreenPreview() {
    MCQMasterTheme {
        SettingsScreen(
            storedApiKey = "",
            apiStatus = ApiKeyStatus.NOT_SET,
            testState = SettingsTestState(),
            preferences = AppPreferences(),
            listState = rememberLazyListState(),
            strings = AppStrings.get(AppLanguage.ENGLISH),
            onSaveApiKey = {},
            onTestConnection = {},
            onSoundEffectsChange = {},
            onExplanationModeChange = {},
            onLanguageChange = {},
            onOpenDeleteHistory = {}
        )
    }
}
