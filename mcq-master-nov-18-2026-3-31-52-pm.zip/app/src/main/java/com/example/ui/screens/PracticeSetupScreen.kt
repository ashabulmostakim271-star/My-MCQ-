package com.example.ui.screens

import android.content.res.Configuration
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyListState
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.UploadFile
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExposedDropdownMenuBox
import androidx.compose.material3.ExposedDropdownMenuDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.MenuAnchorType
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import com.example.data.local.AppLanguage
import com.example.data.local.ChapterWithCount
import com.example.data.local.SubjectWithStats
import com.example.ui.QuestionCountOption
import com.example.ui.QuestionOrder
import com.example.ui.QuizSetupState
import com.example.ui.components.ElevatedBrandCard
import com.example.ui.components.PrimaryActionButton
import com.example.ui.components.SecondaryActionButton
import com.example.ui.theme.CorrectGreen
import com.example.ui.theme.CorrectGreenBg
import com.example.ui.theme.MCQMasterTheme
import com.example.ui.theme.PrimaryBlue
import com.example.ui.theme.PrimaryBlueLight
import com.example.ui.theme.WarningOrange
import com.example.ui.theme.WarningOrangeBg
import com.example.util.AppStrings
import com.example.util.LocalizedStrings

@OptIn(ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class)
@Composable
fun PracticeSetupScreen(
    setupState: QuizSetupState,
    subjects: List<SubjectWithStats>,
    allChapters: List<ChapterWithCount>,
    listState: LazyListState,
    strings: LocalizedStrings,
    onSelectSubject: (Long) -> Unit,
    onSelectChapter: (Long?) -> Unit,
    onSelectQuestionCount: (QuestionCountOption) -> Unit,
    onSelectOrder: (QuestionOrder) -> Unit,
    onStartPractice: () -> Unit,
    onGoToImport: () -> Unit,
    modifier: Modifier = Modifier
) {
    LaunchedEffect(subjects, setupState.selectedSubjectId) {
        if (setupState.selectedSubjectId == null && subjects.isNotEmpty()) {
            val preferred = subjects.firstOrNull { it.mcqCount > 0 } ?: subjects.first()
            onSelectSubject(preferred.id)
        }
    }

    val selectedSubject by remember(subjects, setupState.selectedSubjectId) {
        derivedStateOf { subjects.find { it.id == setupState.selectedSubjectId } }
    }
    val chaptersForSubject by remember(setupState.selectedSubjectId, allChapters) {
        derivedStateOf { allChapters.filter { it.subjectId == setupState.selectedSubjectId } }
    }
    val selectedChapter by remember(chaptersForSubject, setupState.selectedChapterId) {
        derivedStateOf { chaptersForSubject.find { it.id == setupState.selectedChapterId } }
    }

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background),
        contentAlignment = Alignment.TopCenter
    ) {
        LazyColumn(
            state = listState,
            modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            if (subjects.isEmpty()) {
                item(key = "practice_empty_card") {
                    ElevatedBrandCard {
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(24.dp),
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.spacedBy(12.dp)
                        ) {
                            Text(
                                text = strings.emptyHomeTitle,
                                style = MaterialTheme.typography.headlineSmall
                            )
                            Text(
                                text = strings.emptyHomeSubtitle,
                                style = MaterialTheme.typography.bodyMedium,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                            SecondaryActionButton(
                                text = strings.menuImportMcq,
                                onClick = onGoToImport,
                                icon = Icons.Default.UploadFile,
                                modifier = Modifier.fillMaxWidth()
                            )
                        }
                    }
                }
            } else {
                item(key = "practice_setup_card") {
                    QuizSetupFormCard(
                        setupState = setupState,
                        subjects = subjects,
                        selectedSubject = selectedSubject,
                        chaptersForSubject = chaptersForSubject,
                        selectedChapter = selectedChapter,
                        strings = strings,
                        onSelectSubject = onSelectSubject,
                        onSelectChapter = onSelectChapter,
                        onSelectQuestionCount = onSelectQuestionCount,
                        onSelectOrder = onSelectOrder
                    )
                }

                item(key = "start_practice_btn") {
                    PrimaryActionButton(
                        text = strings.startPractice,
                        onClick = onStartPractice,
                        enabled = setupState.validInSelection > 0,
                        icon = Icons.Default.PlayArrow,
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("start_practice_button")
                    )
                }

                if (setupState.validInSelection == 0) {
                    item(key = "go_to_import_btn") {
                        SecondaryActionButton(
                            text = strings.menuImportMcq,
                            onClick = onGoToImport,
                            icon = Icons.Default.UploadFile,
                            modifier = Modifier.fillMaxWidth()
                        )
                    }
                }

                item(key = "practice_spacer") {
                    Spacer(Modifier.height(8.dp))
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class)
@Composable
private fun QuizSetupFormCard(
    setupState: QuizSetupState,
    subjects: List<SubjectWithStats>,
    selectedSubject: SubjectWithStats?,
    chaptersForSubject: List<ChapterWithCount>,
    selectedChapter: ChapterWithCount?,
    strings: LocalizedStrings,
    onSelectSubject: (Long) -> Unit,
    onSelectChapter: (Long?) -> Unit,
    onSelectQuestionCount: (QuestionCountOption) -> Unit,
    onSelectOrder: (QuestionOrder) -> Unit
) {
    var subjectExpanded by remember { mutableStateOf(false) }
    var chapterExpanded by remember { mutableStateOf(false) }

    ElevatedBrandCard {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            Text(
                text = strings.quizSetupTitle,
                style = MaterialTheme.typography.headlineSmall,
                color = PrimaryBlue,
                fontWeight = FontWeight.Bold
            )

            // Subject Picker
            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Text(text = strings.selectSubject, style = MaterialTheme.typography.titleSmall)
                ExposedDropdownMenuBox(
                    expanded = subjectExpanded,
                    onExpandedChange = { subjectExpanded = !subjectExpanded }
                ) {
                    OutlinedTextField(
                        value = selectedSubject?.let { "${it.iconEmoji} ${it.name}" } ?: "",
                        onValueChange = {},
                        readOnly = true,
                        trailingIcon = {
                            ExposedDropdownMenuDefaults.TrailingIcon(expanded = subjectExpanded)
                        },
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier
                            .menuAnchor(MenuAnchorType.PrimaryNotEditable)
                            .fillMaxWidth()
                            .testTag("practice_subject_dropdown")
                    )
                    ExposedDropdownMenu(
                        expanded = subjectExpanded,
                        onDismissRequest = { subjectExpanded = false },
                        containerColor = MaterialTheme.colorScheme.background
                    ) {
                        subjects.forEach { subj ->
                            DropdownMenuItem(
                                text = { Text("${subj.iconEmoji} ${subj.name} (${subj.mcqCount})") },
                                onClick = {
                                    onSelectSubject(subj.id)
                                    subjectExpanded = false
                                },
                                modifier = Modifier.heightIn(min = 52.dp)
                            )
                        }
                    }
                }
            }

            // Chapter Picker
            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Text(text = strings.selectChapter, style = MaterialTheme.typography.titleSmall)
                ExposedDropdownMenuBox(
                    expanded = chapterExpanded,
                    onExpandedChange = { chapterExpanded = !chapterExpanded }
                ) {
                    OutlinedTextField(
                        value = selectedChapter?.name ?: strings.allChapters,
                        onValueChange = {},
                        readOnly = true,
                        trailingIcon = {
                            ExposedDropdownMenuDefaults.TrailingIcon(expanded = chapterExpanded)
                        },
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier
                            .menuAnchor(MenuAnchorType.PrimaryNotEditable)
                            .fillMaxWidth()
                            .testTag("practice_chapter_dropdown")
                    )
                    ExposedDropdownMenu(
                        expanded = chapterExpanded,
                        onDismissRequest = { chapterExpanded = false },
                        containerColor = MaterialTheme.colorScheme.background
                    ) {
                        DropdownMenuItem(
                            text = { Text(strings.allChapters, fontWeight = FontWeight.SemiBold) },
                            onClick = {
                                onSelectChapter(null)
                                chapterExpanded = false
                            },
                            modifier = Modifier.heightIn(min = 52.dp)
                        )
                        chaptersForSubject.forEach { chapter ->
                            DropdownMenuItem(
                                text = { Text("${chapter.name} (${chapter.validMcqCount})") },
                                onClick = {
                                    onSelectChapter(chapter.id)
                                    chapterExpanded = false
                                },
                                modifier = Modifier.heightIn(min = 52.dp)
                            )
                        }
                    }
                }
            }

            // Number of Questions
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text(text = strings.numberOfQuestions, style = MaterialTheme.typography.titleSmall)
                FlowRow(
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    QuestionCountOption.entries.forEach { option ->
                        val label = option.limit?.toString() ?: strings.allQuestions
                        FilterChip(
                            selected = setupState.questionCountOption == option,
                            onClick = { onSelectQuestionCount(option) },
                            label = { Text(label) },
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = PrimaryBlueLight,
                                selectedLabelColor = PrimaryBlue
                            ),
                            modifier = Modifier
                                .heightIn(min = 52.dp)
                                .testTag("count_chip_${option.name.lowercase()}")
                        )
                    }
                }
            }

            // Order
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text(text = strings.questionOrder, style = MaterialTheme.typography.titleSmall)
                FlowRow(
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    FilterChip(
                        selected = setupState.order == QuestionOrder.RANDOM,
                        onClick = { onSelectOrder(QuestionOrder.RANDOM) },
                        label = { Text(strings.orderRandom) },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = PrimaryBlueLight,
                            selectedLabelColor = PrimaryBlue
                        ),
                        modifier = Modifier
                            .heightIn(min = 52.dp)
                            .testTag("order_chip_random")
                    )
                    FilterChip(
                        selected = setupState.order == QuestionOrder.SEQUENTIAL,
                        onClick = { onSelectOrder(QuestionOrder.SEQUENTIAL) },
                        label = { Text(strings.orderSequential) },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = PrimaryBlueLight,
                            selectedLabelColor = PrimaryBlue
                        ),
                        modifier = Modifier
                            .heightIn(min = 52.dp)
                            .testTag("order_chip_sequential")
                    )
                }
            }

            // Availability Banner
            val hasValid = setupState.validInSelection > 0
            Surface(
                shape = RoundedCornerShape(12.dp),
                color = if (hasValid) CorrectGreenBg else WarningOrangeBg,
                border = BorderStroke(
                    1.dp,
                    if (hasValid) CorrectGreen.copy(alpha = 0.4f) else WarningOrange.copy(alpha = 0.4f)
                ),
                modifier = Modifier.fillMaxWidth()
            ) {
                Text(
                    text = if (hasValid) {
                        strings.availableMcqsInfo(
                            setupState.validInSelection,
                            setupState.unknownInSelection
                        )
                    } else {
                        strings.noValidMcqsMsg
                    },
                    style = MaterialTheme.typography.bodyMedium,
                    color = if (hasValid) CorrectGreen else WarningOrange,
                    fontWeight = FontWeight.SemiBold,
                    modifier = Modifier.padding(12.dp)
                )
            }
        }
    }
}

@Preview(
    showBackground = true,
    showSystemUi = true,
    device = "spec:width=360dp,height=800dp,dpi=420",
    uiMode = Configuration.UI_MODE_NIGHT_NO
)
@Composable
private fun PracticeSetupScreenPreview() {
    MCQMasterTheme {
        PracticeSetupScreen(
            setupState = QuizSetupState(
                selectedSubjectId = 1L,
                validInSelection = 25,
                totalInSelection = 25
            ),
            subjects = listOf(SubjectWithStats(1L, "Physics", "⚛️", 2, 25)),
            allChapters = emptyList(),
            listState = rememberLazyListState(),
            strings = AppStrings.get(AppLanguage.ENGLISH),
            onSelectSubject = {},
            onSelectChapter = {},
            onSelectQuestionCount = {},
            onSelectOrder = {},
            onStartPractice = {},
            onGoToImport = {}
        )
    }
}
