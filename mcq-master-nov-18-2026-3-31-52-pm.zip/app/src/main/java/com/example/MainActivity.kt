package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.animation.AnimatedContentTransitionScope
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.lazy.grid.rememberLazyGridState
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.SideEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.core.splashscreen.SplashScreen.Companion.installSplashScreen
import androidx.core.view.WindowCompat
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavDestination.Companion.hasRoute
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import com.example.ui.MainViewModel
import com.example.ui.MainViewModelFactory
import com.example.ui.components.McqBottomNavBar
import com.example.ui.components.McqTopAppBar
import com.example.ui.navigation.NavRoute
import com.example.ui.screens.AboutScreen
import com.example.ui.screens.DeleteHistoryScreen
import com.example.ui.screens.HistoryScreen
import com.example.ui.screens.HomeScreen
import com.example.ui.screens.ImportMcqScreen
import com.example.ui.screens.ManageSubjectsScreen
import com.example.ui.screens.PracticeSetupScreen
import com.example.ui.screens.QuizScreen
import com.example.ui.screens.ResultsScreen
import com.example.ui.screens.SettingsScreen
import com.example.ui.theme.BackgroundWhite
import com.example.ui.theme.MCQMasterTheme
import com.example.ui.theme.PrimaryBlue
import com.example.util.AppStrings
import com.example.util.SoundEffectHelper
import com.google.accompanist.systemuicontroller.rememberSystemUiController

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        val splashScreen = installSplashScreen()
        super.onCreate(savedInstanceState)
        WindowCompat.setDecorFitsSystemWindows(window, false)

        val app = application as McqMasterApplication
        val factory = MainViewModelFactory(
            repository = app.repository,
            soundEffectHelper = SoundEffectHelper()
        )

        var keepSplash = true
        splashScreen.setKeepOnScreenCondition { keepSplash }

        setContent {
            MCQMasterTheme {
                val systemUiController = rememberSystemUiController()
                SideEffect {
                    systemUiController.setStatusBarColor(
                        color = PrimaryBlue,
                        darkIcons = false
                    )
                    systemUiController.setNavigationBarColor(
                        color = BackgroundWhite,
                        darkIcons = true
                    )
                }

                val viewModel: MainViewModel = viewModel(factory = factory)
                val isReady by viewModel.isInitialDataReady.collectAsStateWithLifecycle()
                keepSplash = !isReady

                McqMasterApp(viewModel = viewModel)
            }
        }
    }
}

@Composable
fun McqMasterApp(viewModel: MainViewModel) {
    val navController = rememberNavController()
    val backStackEntry by navController.currentBackStackEntryAsState()
    val destination = backStackEntry?.destination

    val subjects by viewModel.subjectsWithStats.collectAsStateWithLifecycle()
    val allChapters by viewModel.allChapters.collectAsStateWithLifecycle()
    val homeUiState by viewModel.homeUiState.collectAsStateWithLifecycle()
    val historyUiState by viewModel.historyUiState.collectAsStateWithLifecycle()
    val inputHistoryUiState by viewModel.inputHistoryUiState.collectAsStateWithLifecycle()
    val preferences by viewModel.preferences.collectAsStateWithLifecycle()
    val apiKey by viewModel.apiKey.collectAsStateWithLifecycle()
    val apiStatus by viewModel.apiStatus.collectAsStateWithLifecycle()
    val importState by viewModel.importState.collectAsStateWithLifecycle()
    val quizSetupState by viewModel.quizSetupState.collectAsStateWithLifecycle()
    val activeQuizState by viewModel.activeQuizState.collectAsStateWithLifecycle()
    val quizResultState by viewModel.quizResultState.collectAsStateWithLifecycle()
    val settingsTestState by viewModel.settingsTestState.collectAsStateWithLifecycle()
    val historyFilter by viewModel.historySubjectFilter.collectAsStateWithLifecycle()
    val snackbarMessage by viewModel.snackbarMessage.collectAsStateWithLifecycle()

    val strings = remember(preferences.language) { AppStrings.get(preferences.language) }
    val snackbarHostState = remember { SnackbarHostState() }

    val homeGridState = rememberLazyGridState()
    val practiceListState = rememberLazyListState()
    val historyListState = rememberLazyListState()
    val settingsListState = rememberLazyListState()

    LaunchedEffect(snackbarMessage) {
        val msg = snackbarMessage
        if (msg != null) {
            snackbarHostState.showSnackbar(msg)
            viewModel.consumeSnackbar()
        }
    }

    val currentTopTab: NavRoute? = when {
        destination?.hasRoute<NavRoute.Home>() == true -> NavRoute.Home
        destination?.hasRoute<NavRoute.Practice>() == true -> NavRoute.Practice
        destination?.hasRoute<NavRoute.History>() == true -> NavRoute.History
        destination?.hasRoute<NavRoute.Settings>() == true -> NavRoute.Settings
        else -> null
    }

    val showBottomNavigation = currentTopTab != null
    val isQuizActiveScreen = destination?.hasRoute<NavRoute.Quiz>() == true
    val showBackArrow = !showBottomNavigation && !isQuizActiveScreen

    val screenTitle = when {
        destination?.hasRoute<NavRoute.Home>() == true -> strings.appName
        destination?.hasRoute<NavRoute.Practice>() == true -> strings.practiceTitle
        destination?.hasRoute<NavRoute.History>() == true -> strings.historyTitle
        destination?.hasRoute<NavRoute.Settings>() == true -> strings.settingsTitle
        destination?.hasRoute<NavRoute.ImportMcq>() == true -> strings.importTitle
        destination?.hasRoute<NavRoute.ManageSubjects>() == true -> strings.manageSubjectsTitle
        destination?.hasRoute<NavRoute.DeleteHistory>() == true -> strings.deleteHistoryTitle
        destination?.hasRoute<NavRoute.Quiz>() == true -> strings.practiceTitle
        destination?.hasRoute<NavRoute.Results>() == true -> strings.resultsTitle
        destination?.hasRoute<NavRoute.About>() == true -> strings.aboutTitle
        else -> strings.appName
    }

    fun navigateToTopTab(route: NavRoute) {
        navController.navigate(route) {
            popUpTo(navController.graph.findStartDestination().id) {
                saveState = true
            }
            launchSingleTop = true
            restoreState = true
        }
    }

    Scaffold(
        modifier = Modifier
            .fillMaxSize()
            .background(BackgroundWhite),
        containerColor = BackgroundWhite,
        contentWindowInsets = WindowInsets(0, 0, 0, 0),
        snackbarHost = {
            SnackbarHost(
                hostState = snackbarHostState,
                modifier = if (!showBottomNavigation) {
                    Modifier.windowInsetsPadding(WindowInsets.navigationBars)
                } else {
                    Modifier
                }
            )
        },
        topBar = {
            McqTopAppBar(
                title = screenTitle,
                strings = strings,
                showBackButton = showBackArrow,
                onBackClick = { navController.popBackStack() },
                onNavigateImport = {
                    navController.navigate(NavRoute.ImportMcq) { launchSingleTop = true }
                },
                onNavigateManageSubjects = {
                    navController.navigate(NavRoute.ManageSubjects) { launchSingleTop = true }
                },
                onNavigateDeleteHistory = {
                    navController.navigate(NavRoute.DeleteHistory) { launchSingleTop = true }
                },
                onNavigateAbout = {
                    navController.navigate(NavRoute.About) { launchSingleTop = true }
                }
            )
        },
        bottomBar = {
            if (showBottomNavigation) {
                McqBottomNavBar(
                    currentRoute = currentTopTab,
                    strings = strings,
                    onSelectTab = ::navigateToTopTab
                )
            }
        }
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .let { mod ->
                    if (!showBottomNavigation) {
                        mod.windowInsetsPadding(WindowInsets.navigationBars)
                    } else {
                        mod
                    }
                }
        ) {
            NavHost(
                navController = navController,
                startDestination = NavRoute.Home,
                modifier = Modifier.fillMaxSize(),
                enterTransition = {
                    slideIntoContainer(
                        towards = AnimatedContentTransitionScope.SlideDirection.Start,
                        animationSpec = tween(250)
                    ) + fadeIn(tween(250))
                },
                exitTransition = {
                    slideOutOfContainer(
                        towards = AnimatedContentTransitionScope.SlideDirection.Start,
                        animationSpec = tween(250)
                    ) + fadeOut(tween(200))
                },
                popEnterTransition = {
                    slideIntoContainer(
                        towards = AnimatedContentTransitionScope.SlideDirection.End,
                        animationSpec = tween(250)
                    ) + fadeIn(tween(250))
                },
                popExitTransition = {
                    slideOutOfContainer(
                        towards = AnimatedContentTransitionScope.SlideDirection.End,
                        animationSpec = tween(250)
                    ) + fadeOut(tween(200))
                }
            ) {
                composable<NavRoute.Home> {
                    HomeScreen(
                        homeUiState = homeUiState,
                        gridState = homeGridState,
                        apiStatus = apiStatus,
                        strings = strings,
                        onAddSubject = { name, emoji ->
                            viewModel.addSubject(name, emoji)
                        },
                        onSubjectClick = { subjectId ->
                            viewModel.selectPracticeSubject(subjectId)
                            navigateToTopTab(NavRoute.Practice)
                        },
                        onOpenImport = {
                            navController.navigate(NavRoute.ImportMcq) { launchSingleTop = true }
                        },
                        onOpenSettings = { navigateToTopTab(NavRoute.Settings) }
                    )
                }

                composable<NavRoute.Practice> {
                    PracticeSetupScreen(
                        setupState = quizSetupState,
                        subjects = subjects,
                        allChapters = allChapters,
                        listState = practiceListState,
                        strings = strings,
                        onSelectSubject = viewModel::selectPracticeSubject,
                        onSelectChapter = viewModel::selectPracticeChapter,
                        onSelectQuestionCount = viewModel::selectQuestionCountOption,
                        onSelectOrder = viewModel::selectQuestionOrder,
                        onStartPractice = {
                            viewModel.startPracticeQuiz(
                                onStarted = { navController.navigate(NavRoute.Quiz) },
                                onEmpty = { viewModel.showSnackbar(strings.noValidMcqsMsg) }
                            )
                        },
                        onGoToImport = {
                            navController.navigate(NavRoute.ImportMcq) { launchSingleTop = true }
                        }
                    )
                }

                composable<NavRoute.History> {
                    HistoryScreen(
                        historyUiState = historyUiState,
                        subjects = subjects,
                        selectedSubjectFilter = historyFilter,
                        listState = historyListState,
                        strings = strings,
                        onSelectFilter = viewModel::setHistorySubjectFilter
                    )
                }

                composable<NavRoute.Settings> {
                    SettingsScreen(
                        storedApiKey = apiKey,
                        apiStatus = apiStatus,
                        testState = settingsTestState,
                        preferences = preferences,
                        listState = settingsListState,
                        strings = strings,
                        onSaveApiKey = { key ->
                            viewModel.saveApiKey(key)
                            viewModel.showSnackbar(strings.saveKey)
                        },
                        onTestConnection = viewModel::testApiConnection,
                        onSoundEffectsChange = viewModel::setSoundEffects,
                        onExplanationModeChange = viewModel::setExplanationMode,
                        onLanguageChange = viewModel::setLanguage,
                        onOpenDeleteHistory = {
                            navController.navigate(NavRoute.DeleteHistory) { launchSingleTop = true }
                        }
                    )
                }

                composable<NavRoute.DeleteHistory> {
                    DeleteHistoryScreen(
                        inputHistoryState = inputHistoryUiState,
                        outputHistoryState = historyUiState,
                        strings = strings,
                        onDeleteInputChapters = { ids ->
                            viewModel.deleteSelectedInputHistory(ids) { count ->
                                viewModel.showSnackbar(strings.itemsDeletedMsg(count))
                            }
                        },
                        onDeleteOutputSessions = { ids ->
                            viewModel.deleteSelectedOutputHistory(ids) { count ->
                                viewModel.showSnackbar(strings.itemsDeletedMsg(count))
                            }
                        }
                    )
                }

                composable<NavRoute.ImportMcq> {
                    ImportMcqScreen(
                        importState = importState,
                        subjects = subjects,
                        allChapters = allChapters,
                        apiStatus = apiStatus,
                        strings = strings,
                        onSelectSubject = viewModel::selectImportSubject,
                        onCreateSubject = { name, emoji ->
                            viewModel.addSubject(name, emoji) { newId ->
                                viewModel.selectImportSubject(newId)
                            }
                        },
                        onChapterNameChange = viewModel::updateImportChapterName,
                        onFilePicked = viewModel::onSourceFilePicked,
                        onExtractClick = {
                            viewModel.extractMcqsWithGemini(strings.noMcqsFoundMsg)
                        },
                        onUpdateDraft = viewModel::updateDraftMcq,
                        onDeleteDraft = viewModel::deleteDraftMcq,
                        onSaveMcqs = {
                            viewModel.saveExtractedMcqs { savedCount ->
                                viewModel.showSnackbar(strings.savedSuccessMsg(savedCount))
                                navController.popBackStack()
                            }
                        },
                        onOpenSettings = { navigateToTopTab(NavRoute.Settings) }
                    )
                }

                composable<NavRoute.ManageSubjects> {
                    ManageSubjectsScreen(
                        subjects = subjects,
                        allChapters = allChapters,
                        strings = strings,
                        onAddSubject = { name, emoji -> viewModel.addSubject(name, emoji) },
                        onUpdateSubject = viewModel::updateSubject,
                        onDeleteSubject = viewModel::deleteSubject,
                        onDeleteChapter = viewModel::deleteChapter
                    )
                }

                composable<NavRoute.Quiz> {
                    QuizScreen(
                        quizState = activeQuizState,
                        explanationMode = preferences.explanationMode,
                        language = preferences.language,
                        strings = strings,
                        onSelectOption = viewModel::submitAnswer,
                        onSkipQuestion = {
                            viewModel.skipCurrentQuestion {
                                navController.navigate(NavRoute.Results) {
                                    popUpTo(NavRoute.Quiz) { inclusive = true }
                                }
                            }
                        },
                        onNextQuestion = {
                            viewModel.moveToNextQuestion {
                                navController.navigate(NavRoute.Results) {
                                    popUpTo(NavRoute.Quiz) { inclusive = true }
                                }
                            }
                        },
                        onExitQuiz = {
                            viewModel.cancelActiveQuiz()
                            navController.popBackStack()
                        }
                    )
                }

                composable<NavRoute.Results> {
                    ResultsScreen(
                        resultState = quizResultState,
                        strings = strings,
                        onRetryWrongAnswers = {
                            viewModel.retryWrongAnswers {
                                navController.navigate(NavRoute.Quiz) {
                                    popUpTo(NavRoute.Results) { inclusive = true }
                                }
                            }
                        },
                        onBackToHome = { navigateToTopTab(NavRoute.Home) }
                    )
                }

                composable<NavRoute.About> {
                    AboutScreen(strings = strings)
                }
            }
        }
    }
}
